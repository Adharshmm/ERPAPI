﻿using AutoMapper;
using Dapper;
using ERPAPI.Data.Dapper;
using ERPAPI.Data.EF;
using ERPAPI.Data.Entities;
using ERPAPI.Dtos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Net;
using System.Net.Http.Headers;
using System.Reflection.Metadata;
namespace ERPAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeDapper2Controller : ControllerBase
    {
        private readonly EmployeeDapperContext _context;
        private readonly IMapper _mapper;
        public EmployeeDapper2Controller(EmployeeDapperContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<ActionResult<Boolean>> AddAsync(EmployeeDto oEmployeeDto)
        {

            string qryInsertEmployee = "INSERT INTO EmployeeDetails (firstName, lastName, dateofBirth, personalEmail, mobileNumber, postalAddress, gender, country, city, designation, basicPay, needTransportation, notes, username, password) VALUES (@firstName, @lastName, @dateofBirth, @personalEmail, @mobileNumber, @postalAddress, @gender, @country, @city, @designation, @basicPay, @needTransportation, @notes, @username, @password)";
            DynamicParameters parametrs = new DynamicParameters();
            parametrs.Add("firstName", oEmployeeDto.FirstName);
            parametrs.Add("lastName", oEmployeeDto.LastName);
            parametrs.Add("dateofBirth", oEmployeeDto.DateofBirth);
            parametrs.Add("personalEmail", oEmployeeDto.PersonalEmail);
            parametrs.Add("mobileNumber", oEmployeeDto.MobileNumber);
            parametrs.Add("postalAddress", oEmployeeDto.PostalAddress);
            parametrs.Add("gender", oEmployeeDto.Gender);
            parametrs.Add("country", oEmployeeDto.Country);
            parametrs.Add("city", oEmployeeDto.City);
            parametrs.Add("designation", oEmployeeDto.Designation);
            parametrs.Add("basicPay", oEmployeeDto.BasicPay);
            parametrs.Add("needTransportation", oEmployeeDto.NeedTransportation);
            parametrs.Add("notes", oEmployeeDto.Notes ?? (object)DBNull.Value);
            parametrs.Add("username", oEmployeeDto.Username);
            parametrs.Add("password", oEmployeeDto.Password);

            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                dbConnection.Open();

                IDbTransaction transaction = dbConnection.BeginTransaction();

                try
                {
                    int numRecordsAffected = await dbConnection.ExecuteAsync(qryInsertEmployee, parametrs, transaction);
                    if (numRecordsAffected == 1)
                    {


                        int NewEmployeeId = dbConnection.ExecuteScalar<int>("SELECt @@IDENTITY", null, transaction);

                        foreach (WorkExperienceDto workExperienceDto in oEmployeeDto.WorkExperiences)
                        {
                            workExperienceDto.EmployeeId = NewEmployeeId;
                        }
                        string qryInsertWorkExperience = "INSERT INTO WorkExperiences (EmployeeId, Company, NumberOfMonths, LastDesignation, Remarks) VALUES (@EmployeeId, @Company, @NumberOfMonths, @LastDesignation, @Remarks);";
                        int numWorkExpAdded = await dbConnection.ExecuteAsync(qryInsertWorkExperience, oEmployeeDto.WorkExperiences, transaction);
                        if(numWorkExpAdded == oEmployeeDto.WorkExperiences.Count)
                        {
                            transaction.Commit();

                            return Ok(true);
                        }
                        else
                        {
                            transaction.Rollback();
                            return Ok(false);
                        }

                    }
                    else
                    {
                        transaction.Rollback();
                        return StatusCode(StatusCodes.Status500InternalServerError);
                    }

                }
                catch
                {
                    transaction.Rollback();
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
                finally
                {
                    transaction.Dispose();
                }

            }
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmployeeDto>>> GetAsync()
        {
            string qryGetEmployees = "SELECT * FROM EmployeeDetails";
            try
            {
                using (IDbConnection dbConnection = _context.CreateConnection())
                {
                    IEnumerable<Employee> employees = await dbConnection.QueryAsync<Employee>(qryGetEmployees);
                    foreach (Employee employee in employees.ToList())
                    {
                        string qryGetWorkExp = "select * from WorkExperiences where EmployeeId = @EmployeeId";
                        DynamicParameters parameters = new DynamicParameters();
                        parameters.Add("EmployeeId", employee.EmployeeId);

                        IEnumerable<WorkExperience> WorkExp = await dbConnection.QueryAsync<WorkExperience>(qryGetWorkExp,parameters);
                        employee.WorkExperiences = WorkExp.ToList();
                    }

                    List<EmployeeDto> employeeDtos = _mapper.Map<List<Employee>, List<EmployeeDto>>(employees.ToList());

                    return Ok(employeeDtos);
                }
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);

            }


        }


        [HttpGet("{Id}")]
        public async Task<ActionResult<EmployeeDto>> GetAsync(int Id)
        {
            string qryGetEmployees = "SELECT * FROM EmployeeDetails Where EmployeeId = @Id";

            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Id", Id);

            try
            {
                using (IDbConnection dbConnection = _context.CreateConnection())
                {
                    Employee objEmployee = await dbConnection.QuerySingleOrDefaultAsync<Employee>(qryGetEmployees, parameters);

                    if (objEmployee != null)
                    {
                        //get workexp
                        string qryGetWorkExp = "select * from WorkExperiences Where EmployeeId = @Id";

                        DynamicParameters WorkExParameter = new DynamicParameters();
                        WorkExParameter.Add("Id", objEmployee.EmployeeId);

                        IEnumerable<WorkExperience> WorkExp = await dbConnection.QueryAsync<WorkExperience>(qryGetWorkExp, WorkExParameter);
                        objEmployee.WorkExperiences = WorkExp.ToList();

                        EmployeeDto objEmployeeDto = _mapper.Map<Employee, EmployeeDto>(objEmployee);
                        return Ok(objEmployeeDto);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError);
            }


        }


        [HttpPut]
        [Route("{Id}")]
        public async Task<ActionResult<EmployeeDto>> PutAsync(int Id, [FromBody] EmployeeDto objEmployeeDto)
        {
            string qryUpdateEmployees = "UPDATE EmployeeDetails SET firstName=@firstName, lastName=@lastName, dateofBirth=@dateofBirth, personalEmail=@personalEmail, mobileNumber=@mobileNumber, postalAddress=@postalAddress, gender=@gender, country=@country, city=@city, designation=@designation, basicPay=@basicPay, needTransportation=@needTransportation, notes=@notes, username=@username, password=@password WHERE  EmployeeId = @Id";

            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Id", Id);
            parameters.Add("firstName", objEmployeeDto.FirstName);
            parameters.Add("lastName", objEmployeeDto.LastName);
            parameters.Add("dateofBirth", objEmployeeDto.DateofBirth);
            parameters.Add("personalEmail", objEmployeeDto.PersonalEmail);
            parameters.Add("mobileNumber", objEmployeeDto.MobileNumber);
            parameters.Add("postalAddress", objEmployeeDto.PostalAddress);
            parameters.Add("gender", objEmployeeDto.Gender);
            parameters.Add("country", objEmployeeDto.Country);
            parameters.Add("city", objEmployeeDto.City);
            parameters.Add("designation", objEmployeeDto.Designation);
            parameters.Add("basicPay", objEmployeeDto.BasicPay);
            parameters.Add("needTransportation", objEmployeeDto.NeedTransportation);
            parameters.Add("notes", objEmployeeDto.Notes ?? (object)DBNull.Value);
            parameters.Add("username", objEmployeeDto.Username);
            parameters.Add("password", objEmployeeDto.Password);

            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                dbConnection.Open();
                IDbTransaction transaction = dbConnection.BeginTransaction();

                try
                {
                    int numRecordsAffected = await dbConnection.ExecuteAsync(qryUpdateEmployees, parameters, transaction);
                    if (numRecordsAffected == 1)
                    {
                        //delete exsisting workexp
                        string qryDeleteWorkExp = "Delete from WorkExperiences where EmployeeId = @Id ";
                        DynamicParameters deleteWrkExParameter = new DynamicParameters();
                        deleteWrkExParameter.Add("Id", objEmployeeDto.EmployeeId);

                        await dbConnection.ExecuteAsync(qryDeleteWorkExp, deleteWrkExParameter, transaction);
                        foreach (WorkExperienceDto workExperienceDto in objEmployeeDto.WorkExperiences)
                        {
                            workExperienceDto.EmployeeId = objEmployeeDto.EmployeeId;
                        }
                        string qryInsertWorkExperience = "INSERT INTO WorkExperiences (EmployeeId, Company, NumberOfMonths, LastDesignation, Remarks) VALUES (@EmployeeId, @Company, @NumberOfMonths, @LastDesignation, @Remarks);";
                        int numWorkExpAdded = await dbConnection.ExecuteAsync(qryInsertWorkExperience, objEmployeeDto.WorkExperiences, transaction);
                        if (numWorkExpAdded == objEmployeeDto.WorkExperiences.Count)
                        {
                            transaction.Commit();

                            return Ok(true);
                        }
                        else
                        {
                            transaction.Rollback();
                            return Ok(false);
                        }

                    }
                    else
                    {
                        transaction.Rollback();
                        return StatusCode(StatusCodes.Status500InternalServerError);
                    }

                }
                catch(Exception)
                {
                    transaction.Rollback();
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
                finally
                {
                    transaction.Dispose();
                }

            }
        }

    


        [HttpDelete]
        [Route("{Id}")]
        public async Task<ActionResult<Boolean>> DeleteAsync(int Id)
        {

            string qryDeleteWorkExp = "DELETE FROM WorkExperiences WHERE employeeId = @Id ";
            string qryDeleteEmployees = "DELETE FROM EmployeeDetails WHERE employeeId = @Id ";
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Id", Id);
            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                dbConnection.Open();
                IDbTransaction transaction = dbConnection.BeginTransaction(); 
                try
                {
                    await dbConnection.ExecuteAsync(qryDeleteWorkExp, parameters, transaction);

                    int numRecordsAffected = await dbConnection.ExecuteAsync(qryDeleteEmployees, parameters, transaction);
                    if(numRecordsAffected == 1)
                    {
                        transaction.Commit();
                        return Ok(true);
                    }
                    else
                    {
                        transaction.Rollback();
                        return StatusCode(StatusCodes.Status500InternalServerError);
                    }

                }
                catch
                {
                    transaction.Rollback();
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
                finally
                {
                    transaction.Dispose() ;
                }
            }
        }
    } }
    

