﻿using AutoMapper;
using ERPAPI.Data.EF;
using ERPAPI.Data.Entities;
using ERPAPI.Dtos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics.Metrics;
using System.Net;
using System.Net.Http.Headers;
using System.Reflection;
using static Azure.Core.HttpHeader;
namespace ERPAPI.Controllers
{
    [Route("api/Employee")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly EmployeeDetailsDBContext _context;
        private readonly IMapper _mapper;
        public EmployeeController(EmployeeDetailsDBContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }


        [HttpPost]
        public async Task<ActionResult<Boolean>> AddAsync(EmployeeDto oEmployeeDto)
        {

            Employee oEmployee = _mapper.Map<Employee>(oEmployeeDto);

            _context.EmployeeDetails.Add(oEmployee);
            int numRecordAffected = await _context.SaveChangesAsync();
            if (numRecordAffected == 1)
            {
                return Ok(true);
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }


        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmployeeDto>>> GetAsync()
        {
            if (_context.EmployeeDetails == null)
            {
                return NotFound();
            }
            List<Employee> employees = await _context.EmployeeDetails.ToListAsync();
            List<EmployeeDto> employeesDto = _mapper.Map<List<Employee>, List<EmployeeDto>>(employees);
            return Ok(employeesDto);

        }


        [HttpGet("{Id}")]
        public async Task<ActionResult<EmployeeDto>> GetAsync(int Id)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }
            if (_context.EmployeeDetails == null)
            {
                return NotFound();
            }

            Employee objEmployee = await _context.EmployeeDetails.Where(x => x.EmployeeId == Id).FirstOrDefaultAsync();

            if (objEmployee == null)
            {
                return NotFound(new EmployeeDto());
            }

            EmployeeDto objEmployeesDto = _mapper.Map<EmployeeDto>(objEmployee);
            return Ok(objEmployeesDto);

        }


        [HttpPut]
        [Route("{Id}")]
        public async Task<ActionResult<EmployeeDto>> PutAsync(int Id, [FromBody] EmployeeDto objEmployeeDto)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }
            if (_context.EmployeeDetails != null)
            {
                Employee objEmployee = await _context.EmployeeDetails.Where(empl => empl.EmployeeId == Id).AsNoTracking().FirstOrDefaultAsync();
                if (objEmployee == null)
                {
                    return NotFound(new EmployeeDto());
                }


                Employee objModifiedEmployee = _mapper.Map<Employee>(objEmployeeDto);
                _context.EmployeeDetails.Update(objModifiedEmployee);

                int numRecordAffected = await _context.SaveChangesAsync();
                if (numRecordAffected == 1)
                {
                    return Ok(true);
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
            }
            else
            {
                return Ok(HttpStatusCode.InternalServerError);
            }

        }


        [HttpDelete]
        [Route("{Id}")]
        public async Task<ActionResult<EmployeeDto>> DeleteAsync(int Id)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }
            if (_context.EmployeeDetails != null)
            {
                Employee objEmployee = await _context.EmployeeDetails.Where(empl => empl.EmployeeId == Id).FirstOrDefaultAsync();
                if (objEmployee == null)
                {
                    return NotFound();
                }
                _context.EmployeeDetails.Remove(objEmployee);
                int numRecordAffected = await _context.SaveChangesAsync();
                if (numRecordAffected == 1)
                {
                    return Ok(true);
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
            }
            else
            {
                return Ok(HttpStatusCode.InternalServerError);
            }
        }
    }
}
