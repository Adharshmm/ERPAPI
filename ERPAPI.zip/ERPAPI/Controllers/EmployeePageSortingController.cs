﻿using AutoMapper;
using ERPAPI.Data.EF;
using ERPAPI.Data.Entities;
using ERPAPI.Dtos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics.Metrics;
using System.Net;
using System.Net.Http.Headers;
using System.Reflection;
using static Azure.Core.HttpHeader;
namespace ERPAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeePageSortingController : ControllerBase
    {
        private readonly EmployeeDetailsDBContext _context;
        private readonly IMapper _mapper;
        public EmployeePageSortingController(EmployeeDetailsDBContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpGet]
        [Route("Paged/{pageSize}/{pageNum}/{sortedField}/{sortOrder}")]
        public async Task<ActionResult<List<EmployeeDto>>> GetSortedAsync(int pageSize,int pageNum,string sortedField,string sortOrder)
        {
            if(_context.EmployeeDetails == null)
            {
                return NotFound();
            }
            IQueryable<Employee> qrylstEmployee;
            List<Employee> lstEmployee;

            switch (sortedField.ToLower()) 
            {
                case "firstname":
                    qrylstEmployee = (sortOrder.ToLower() == "desc") ? _context.EmployeeDetails.OrderByDescending(e => e.FirstName) :
                        _context.EmployeeDetails.OrderBy(e => e.FirstName);
                    break;
                case "lastname":
                    qrylstEmployee = (sortOrder.ToLower() == "desc") ? _context.EmployeeDetails.OrderByDescending(e => e.LastName) :
                        _context.EmployeeDetails.OrderBy(e => e.LastName);
                    break;
                case "dateofbirth":
                    qrylstEmployee = (sortOrder.ToLower() == "desc") ? _context.EmployeeDetails.OrderByDescending(e => e.DateofBirth) :
                        _context.EmployeeDetails.OrderBy(e => e.DateofBirth);
                    break;
                case "personalemail":
                    qrylstEmployee = (sortOrder.ToLower() == "desc") ? _context.EmployeeDetails.OrderByDescending(e => e.PersonalEmail) :
                        _context.EmployeeDetails.OrderBy(e => e.PersonalEmail);
                    break;
                case "gender":
                    qrylstEmployee = (sortOrder.ToLower() == "desc") ? _context.EmployeeDetails.OrderByDescending(e => e.Gender) :
                        _context.EmployeeDetails.OrderBy(e => e.Gender);
                    break;
                case "country":
                    qrylstEmployee = (sortOrder.ToLower() == "desc") ? _context.EmployeeDetails.OrderByDescending(e => e.Country) :
                        _context.EmployeeDetails.OrderBy(e => e.Country);
                    break;
                case "city":
                    qrylstEmployee = (sortOrder.ToLower() == "desc") ? _context.EmployeeDetails.OrderByDescending(e => e.City) :
                        _context.EmployeeDetails.OrderBy(e => e.City);
                    break;
                case "designation":
                    qrylstEmployee = (sortOrder.ToLower() == "desc") ? _context.EmployeeDetails.OrderByDescending(e => e.Designation) :
                        _context.EmployeeDetails.OrderBy(e => e.Designation);
                    break;
                case "basicpay":
                    qrylstEmployee = (sortOrder.ToLower() == "desc") ? _context.EmployeeDetails.OrderByDescending(e => e.BasicPay) :
                        _context.EmployeeDetails.OrderBy(e => e.BasicPay);
                    break;
                case "needtransportation":
                    qrylstEmployee = (sortOrder.ToLower() == "desc") ? _context.EmployeeDetails.OrderByDescending(e => e.NeedTransportation) :
                        _context.EmployeeDetails.OrderBy(e => e.NeedTransportation);
                    break;
                case "username":
                    qrylstEmployee = (sortOrder.ToLower() == "desc") ? _context.EmployeeDetails.OrderByDescending(e => e.Username) :
                        _context.EmployeeDetails.OrderBy(e => e.Username);
                    break;
                default:
                    qrylstEmployee = (sortOrder.ToLower() == "desc") ? _context.EmployeeDetails.OrderByDescending(e => e.EmployeeId) :
                        _context.EmployeeDetails.OrderBy(e => e.EmployeeId);
                    break;
            }

            lstEmployee = await qrylstEmployee.Skip((pageNum - 1)* pageSize).Take(pageSize).ToListAsync();
            List<EmployeeDto> employeeDto = _mapper.Map<List<Employee>, List<EmployeeDto>>(lstEmployee);

            return Ok(employeeDto);
        }


    }
}
