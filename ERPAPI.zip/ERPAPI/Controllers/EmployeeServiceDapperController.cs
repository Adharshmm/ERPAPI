﻿using AutoMapper;
using ERPAPI.Data.Dapper;
using ERPAPI.Data.EF;
using ERPAPI.Data.Entities;
using ERPAPI.Dtos;
using ERPAPI.Services.DB.Dapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Net.Http.Headers;
namespace ERPAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeServiceDapperController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly EmployeeDA _employeeDA;
        public EmployeeServiceDapperController(EmployeeDapperContext context, IMapper mapper)
        {
            _mapper = mapper;
            _employeeDA = new EmployeeDA(context);
        }

        [HttpPost]
        public async Task<ActionResult<Boolean>> AddAsync(EmployeeDto oEmployeeDto) 
        {

            Employee oEmployee = _mapper.Map<Employee>(oEmployeeDto);

            int numRecordAffected = await _employeeDA.Insert(oEmployee);
            if (numRecordAffected > 0)
            {
                return Ok(true);
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError, false);
            }


        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmployeeDto>>> GetAsync()
        {
            if (!_employeeDA.IsEmployeeListNull())
            {
                return NotFound();
            }
            List<Employee> employees = await _employeeDA.GetList();

            List<EmployeeDto> employeesDto = _mapper.Map<List<Employee>, List<EmployeeDto>>(employees);

            return Ok(employeesDto);

        }

        [HttpGet("{Id}")]
        public async Task<ActionResult<EmployeeDto>> GetAsync(int Id)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }
            if (!_employeeDA.IsEmployeeListNull())
            {
                return NotFound();
            }

            Employee? objEmployee = await _employeeDA.GetById(Id);

            if (objEmployee == null)
            {
                return NotFound(new EmployeeDto());
            }

            EmployeeDto objEmployeesDto = _mapper.Map<EmployeeDto>(objEmployee);
            return Ok(objEmployeesDto);

        }

        [HttpPut]
        [Route("{Id}")]
        public async Task<ActionResult<EmployeeDto>> PutAsync(int Id, [FromBody] EmployeeDto objEmployeeDto)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }
            if (_employeeDA.IsEmployeeListNull())
            {

                Employee objEmployee = await _employeeDA.GetById(Id);
                if (objEmployee == null)
                {
                    return NotFound();
                }


                Employee objModifiedEmployee = _mapper.Map<Employee>(objEmployeeDto);

                int numRecordAffected = await _employeeDA.EmpUpdate(objModifiedEmployee);
                if (numRecordAffected >= 1)
                {
                    return Ok(true);
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }

        [HttpDelete]
        [Route("{Id}")]
        public async Task<ActionResult<EmployeeDto>> DeleteAsync(int Id)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }
            if (_employeeDA.IsEmployeeListNull())
            {
                Employee objEmployee = await _employeeDA.GetById(Id);
                if (objEmployee == null)
                {
                    return NotFound();
                }

                int numRecordAffected = await _employeeDA.DeleteEmp(objEmployee);
                if (numRecordAffected > 0)
                {
                    return Ok(true);
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }


    }
}
