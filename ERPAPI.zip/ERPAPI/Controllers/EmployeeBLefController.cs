﻿using AutoMapper;
using ERPAPI.Data.EF;
using ERPAPI.Data.Entities;
using ERPAPI.Dtos;
using ERPAPI.Services.BL;
using ERPAPI.Services.DB.Dapper;
using ERPAPI.Services.DB.EF;
using ERPAPI.Services.DB.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Net.Http.Headers;
namespace ERPAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeBLefController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IEmployee2DA _employeeDA;
        private readonly EmployeeBL employeeBL;
        public EmployeeBLefController(IEmployee2DA employeeDA, IMapper mapper)
        {
            _mapper = mapper;
            _employeeDA = employeeDA;
            employeeBL = new EmployeeBL();
        }


        [HttpPost]
        public async Task<ActionResult<Boolean>> AddAsync(EmployeeDto oEmployeeDto)
        {

            Employee oEmployee = _mapper.Map<Employee>(oEmployeeDto);

            int numRecordAffected = await _employeeDA.Insert(oEmployee);
            if (numRecordAffected > 0)
            {
                return Ok(true);
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError, false);
            }


        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmployeeDto>>> GetAsync()
        {
            if (!_employeeDA.IsEmployeeListNull())
            {
                return NotFound();
            }
            List<Employee> employees = await _employeeDA.GetList();

            List<EmployeeBLDto> employeesDto = _mapper.Map<List<Employee>, List<EmployeeBLDto>>(employees);

            return Ok((employeeBL).GetSalaryDetailsList(employeesDto));

        }


        [HttpGet("{Id}")]
        public async Task<ActionResult<IEnumerable<EmployeeBLDto>>> GetAsync(int Id)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }

            if (!_employeeDA.IsEmployeeListNull())
            {
                return NotFound();
            }

            Employee? objEmployeeDetails = await _employeeDA.GetById(Id);

            if (objEmployeeDetails == null)
            {
                return NotFound();
            }

            EmployeeBLDto objEmployeeDetailsDto = _mapper.Map<EmployeeBLDto>(objEmployeeDetails);

            return Ok((employeeBL).GetSalaryDetails(objEmployeeDetailsDto));
        }


        


        [HttpPut]
        [Route("{Id}")]
        public async Task<ActionResult<EmployeeDto>> PutAsync(int Id, [FromBody] EmployeeDto objEmployeeDto)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }
            if (_employeeDA.IsEmployeeListNull())
            {

                Employee objEmployee = await _employeeDA.GetById(Id);
                if (objEmployee == null)
                {
                    return NotFound();
                }


                Employee objModifiedEmployee = _mapper.Map<Employee>(objEmployeeDto);

                int numRecordAffected = await _employeeDA.EmpUpdate(objModifiedEmployee);
                if (numRecordAffected >= 1)
                {
                    return Ok(true);
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }


        [HttpDelete]
        [Route("{Id}")]
        public async Task<ActionResult<EmployeeDto>> DeleteAsync(int Id)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }
            if (_employeeDA.IsEmployeeListNull())
            {
                Employee objEmployee = await _employeeDA.GetById(Id);
                if (objEmployee == null)
                {
                    return NotFound();
                }

                int numRecordAffected = await _employeeDA.DeleteEmp(objEmployee);
                if (numRecordAffected > 0)
                {
                    return Ok(true);
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }


    }
}
