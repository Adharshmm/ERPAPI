﻿using AutoMapper;
using Dapper;
using ERPAPI.Data.Dapper;
using ERPAPI.Data.EF;
using ERPAPI.Data.Entities;
using ERPAPI.Dtos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Net;
using System.Net.Http.Headers;
using System.Reflection.Metadata;
namespace ERPAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeePageSortingDapperController : ControllerBase
    {
        private readonly EmployeeDapperContext _context;
        private readonly IMapper _mapper;
        public EmployeePageSortingDapperController(EmployeeDapperContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }



        [HttpGet]
        [Route("Paged/{pageSize}/{pageNum}/{sortedField}/{sortOrder}")]
        public async Task<ActionResult<List<EmployeeDto>>> GetSortedAsync(int pageSize, int pageNum, string sortedField, string sortOrder)
        {
            IEnumerable<Employee> lstEmployee = new List<Employee>();

            int offsetValue = (pageNum - 1) * pageSize;
            if (sortOrder.ToLower() != "desc")
            {
                sortOrder = "asc";
            }

            string qry = @"
SELECT * FROM EmployeeDetails
ORDER BY " + sortedField + " " + sortOrder + @"
OFFSET " + offsetValue + @" ROWS
FETCH NEXT " + pageSize + @" ROWS ONLY;

SELECT * FROM WorkExperiences
WHERE EmployeeId IN (
    SELECT EmployeeId
    FROM EmployeeDetails
    ORDER BY " + sortedField + @" " + sortOrder + @"
    OFFSET " + offsetValue + @" ROWS
    FETCH NEXT " + pageSize + @" ROWS ONLY
);";
            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                try
                {
                    using (var result = await dbConnection.QueryMultipleAsync(qry))
                    {
                        var employees = (await result.ReadAsync<Employee>()).ToList();
                        var workExperiences = (await result.ReadAsync<WorkExperience>()).ToList();

                        foreach (var employee in employees)
                        {
                            employee.WorkExperiences = workExperiences
                                .Where(w => w.EmployeeId == employee.EmployeeId)
                                .ToList();
                        }

                        List<EmployeeDto> lstEmployeeDto =
                            _mapper.Map<List<EmployeeDto>>(employees);

                        return Ok(lstEmployeeDto);
                    }
                }
                catch (Exception)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
            }
        }
    }
}



