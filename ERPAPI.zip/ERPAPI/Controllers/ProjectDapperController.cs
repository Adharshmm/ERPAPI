﻿using ERPAPI.Data.Entities;
using ERPAPI.Services.DB.Common;
using ERPAPI.Services.DB.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace ERPAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        private readonly IProjectDA projectDA;

        public ProjectController(IProjectDA projectDA)
        {
            this.projectDA = projectDA;
        }

        [HttpPost]
        public async Task<IActionResult> Insert(Project project)
        {
            try
            {
                ServiceResponse result = await projectDA.Insert(project);
                if(result.Status == OperationStatus.Success)
                {
                    return Ok(result);
                }
                else if (result.Status == OperationStatus.Failure)
                {
                    return BadRequest(result);
                }
                else if (result.Status == OperationStatus.NotFound)
                {
                    return NotFound(result);
                }
                else
                {
                    return StatusCode(500, result);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            Project? result = await projectDA.GetById(id);

            if (result == null)
            {
                return NotFound();
            }

            return Ok(result);
        }

        [HttpGet]
        public async Task<IActionResult> GetList()
        {
            return Ok(await projectDA.GetList());
        }

        [HttpPut]
        [Route("{Id}")]
        public async Task<IActionResult> Update(int Id, [FromBody] Project project)
        {
            try
            {
                ServiceResponse result = await projectDA.Update(Id, project);

                if (result.Status == OperationStatus.Success)
                {
                    return Ok(result);
                }
                else if (result.Status == OperationStatus.Failure)
                {
                    return BadRequest(result);
                }
                else if (result.Status == OperationStatus.NotFound)
                {
                    return NotFound(result);
                }
                else
                {
                    return StatusCode(500, result);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {  
            try
            { 
            ServiceResponse result = await projectDA.Delete(id);
                if (result.Status == OperationStatus.Success)
                {
                    return Ok(result);
                }
                else if (result.Status == OperationStatus.Failure)
                {
                    return BadRequest(result);
                }
                else if (result.Status == OperationStatus.NotFound)
                {
                    return NotFound(result);
                }
                else
                {
                    return StatusCode(500, result);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("Paged")]
        public async Task<IActionResult> GetPagedList(int pageNumber,int pageSize)
        {
            return Ok(await projectDA.GetPagedList(pageNumber,pageSize));
        }

        [HttpGet("ProjectManager/{projectManagerId}")]
        public async Task<IActionResult> GetByProjectManager(
            int projectManagerId)
        {
            return Ok(
                await projectDA.GetByProjectManager(
                    projectManagerId));
        }
    }
}