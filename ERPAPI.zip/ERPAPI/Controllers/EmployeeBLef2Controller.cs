﻿using AutoMapper;
using ERPAPI.Data.EF;
using ERPAPI.Data.Entities;
using ERPAPI.Dtos;
using ERPAPI.Services.BL;
using ERPAPI.Services.DB.Dapper;
using ERPAPI.Services.DB.EF;
using ERPAPI.Services.DB.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Net.Http.Headers;
namespace ERPAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeBLef2Controller : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly EmployeeBL2 _employeeBL;
        public EmployeeBLef2Controller(EmployeeBL2 employeeBL, IMapper mapper)
        {
            _mapper = mapper;
            _employeeBL = employeeBL;
        }


        [HttpPost]
        public async Task<ActionResult<Boolean>> AddAsync(EmployeeDto oEmployeeDto)
        {

            Employee oEmployee = _mapper.Map<Employee>(oEmployeeDto);

            int numRecordAffected = await _employeeBL.InsertAsync(oEmployee);
            if (numRecordAffected > 0)
            {
                return Ok(true);
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError, false);
            }


        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmployeeDto>>> GetAsync()
        {
            if (!_employeeBL.IsEmployeeListNull())
            {
                return NotFound();
            }
            List<EmployeeBLDto> employees = await _employeeBL.GetList();

            return Ok(employees);

        }


        [HttpGet("{Id}")]
        public async Task<ActionResult<IEnumerable<EmployeeBLDto>>> GetAsync(int Id)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }

            if (!_employeeBL.IsEmployeeListNull())
            {
                return NotFound();
            }

            EmployeeBLDto? objEmployeeDetails = await _employeeBL.GetById(Id);

            if (objEmployeeDetails == null)
            {
                return NotFound();
            }

            return Ok(objEmployeeDetails);
        }


        


        [HttpPut]
        [Route("{Id}")]
        public async Task<ActionResult<EmployeeBLDto>> PutAsync(int Id, [FromBody] EmployeeDto objEmployeeDto)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }
            if (_employeeBL.IsEmployeeListNull())
            {

                EmployeeBLDto objEmployee = await _employeeBL.GetById(Id);
                if (objEmployee == null)
                {
                    return NotFound();
                }


                Employee objModifiedEmployee = _mapper.Map<Employee>(objEmployeeDto);

                int numRecordAffected = await _employeeBL.EmpUpdate(objModifiedEmployee);
                if (numRecordAffected >= 1)
                {
                    return Ok(true);
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }


        [HttpDelete]
        [Route("{Id}")]
        public async Task<ActionResult<EmployeeDto>> DeleteAsync(int Id)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }
            if (_employeeBL.IsEmployeeListNull())
            {
                int numRecordAffected = await _employeeBL.DeleteEmp(Id);
                
                if (numRecordAffected > 0)
                {
                    return Ok(true);
                }
                else
                {
                    return NotFound();
                }
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }


    }
}
