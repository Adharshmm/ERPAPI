﻿using AutoMapper;
using ERPAPI.Data.EF;
using ERPAPI.Data.Entities;
using ERPAPI.Dtos;
using ERPAPI.Services.DB.Common;
using ERPAPI.Services.DB.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Net.Http.Headers;
namespace ERPAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeService2Controller : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IEmployeeDA _employeeDA;
        public EmployeeService2Controller(IMapper mapper,IEmployeeDA employeeDA)
        {
            _mapper = mapper;
            _employeeDA =  employeeDA;
        }


        [HttpPost]
        public async Task<ActionResult<ServiceResponse>> AddAsync(EmployeeDto oEmployeeDto) 
        {
            
            Employee oEmployee = _mapper.Map<Employee>(oEmployeeDto);
            ServiceResponse ServiceResponse = await _employeeDA.Insert(oEmployee);

            if (ServiceResponse.RecordsAffected > 0)
            {
                return Ok(ServiceResponse);
            }
            else
            {
                return BadRequest(ServiceResponse);
            }


        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmployeeDto>>> GetAsync()
        {
            if (!_employeeDA.IsEmployeeListNull())
            {
                return NotFound();
            }
            List<Employee> employees = await _employeeDA.GetList();

            List<EmployeeDto> employeesDto = _mapper.Map<List<Employee>, List<EmployeeDto>>(employees);

            return Ok(employeesDto);

        }


        [HttpGet("{Id}")]
        public async Task<ActionResult<EmployeeDto>> GetAsync(int Id)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }
            if (!_employeeDA.IsEmployeeListNull())
            {
                return NotFound();
            }

            Employee? objEmployee = await _employeeDA.GetById(Id);   

            if (objEmployee == null)
            {
                return NotFound(new EmployeeDto());
            }

            EmployeeDto objEmployeesDto = _mapper.Map<EmployeeDto>(objEmployee);
            return Ok(objEmployeesDto);

        }


        [HttpPut]
        [Route("{Id}")]
        public async Task<ActionResult<ServiceResponse>> PutAsync(int Id, [FromBody] EmployeeDto objEmployeeDto)
         {
            if (Id <= 0)
            {
                return BadRequest();
            }
            if (_employeeDA.IsEmployeeListNull())
            {
     
                Employee objEmployee = await _employeeDA.GetById(Id);
                if (objEmployee == null)
                {
                    return NotFound();
                }


                Employee objModifiedEmployee = _mapper.Map<Employee>(objEmployeeDto);

                ServiceResponse result = await _employeeDA.EmpUpdate(objModifiedEmployee);
                if (result.Status == 0)
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result);
                }
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }


        [HttpDelete]
        [Route("{Id}")]
        public async Task<ActionResult<ServiceResponse>> DeleteAsync(int Id)
        {

            if (Id <= 0)
            {
                return BadRequest();
            }
            if (_employeeDA.IsEmployeeListNull())
            {
                Employee objEmployee =await  _employeeDA.GetById(Id);
                if (objEmployee == null)
                {
                    return NotFound();
                }

                ServiceResponse ServiceResponse = await _employeeDA.DeleteEmp(objEmployee);
                return Ok(ServiceResponse);


            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }


    }
}
