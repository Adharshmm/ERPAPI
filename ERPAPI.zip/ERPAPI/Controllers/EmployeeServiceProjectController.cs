﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
namespace ERPAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeServiceProjectController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IEmployeeLookupDA _employeeLookDA;
        public EmployeeServiceProjectController(IMapper mapper, IEmployeeLookupDA employeeLookDA)
        {
            _mapper = mapper;
            _employeeLookDA = employeeLookDA;
        }

        [HttpGet]
        [Route("ProjectManagers")]
        public async Task<IActionResult> GetProjectManagers()
        {
            return Ok(await _employeeLookDA.GetProjectManagers());
        }

        [HttpGet]
        [Route("VicePresidents")]
        public async Task<IActionResult> GetVicePresidents()
        {
            return Ok(await _employeeLookDA.GetVicePresidents());
        }




    }
}
