﻿using AutoMapper;
using ERPAPI.Data.EF;
using ERPAPI.Data.Entities;
using ERPAPI.Dtos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ERPAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Employee2Validation2Controller : ControllerBase
    {
        private readonly EmployeeDetailsDBContext _context;
        private readonly IMapper _mapper;

        public Employee2Validation2Controller(
            EmployeeDetailsDBContext context,
            IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<ActionResult<bool>> AddAsync(EmployeeDto2 oEmployeeDto)
        {
            Employee oEmployee = _mapper.Map<Employee>(oEmployeeDto);

            _context.EmployeeDetails.Add(oEmployee);

            int numRecordAffected = await _context.SaveChangesAsync();

            if (numRecordAffected > 0)
            {
                return Ok(true);
            }

            return StatusCode(
                StatusCodes.Status500InternalServerError,
                false);
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmployeeDto2>>> GetAsync()
        {
            List<Employee> employees = await _context.EmployeeDetails
                .Include(e => e.WorkExperiences)
                .ToListAsync();

            List<EmployeeDto2> employeesDto =
                _mapper.Map<List<EmployeeDto2>>(employees);

            return Ok(employeesDto);
        }

        [HttpGet("{Id}")]
        public async Task<ActionResult<EmployeeDto2>> GetAsync(int Id)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }

            Employee objEmployee = await _context.EmployeeDetails
                .Include(e => e.WorkExperiences)
                .FirstOrDefaultAsync(x => x.EmployeeId == Id);

            if (objEmployee == null)
            {
                return NotFound();
            }

            EmployeeDto2 objEmployeeDto =
                _mapper.Map<EmployeeDto2>(objEmployee);

            return Ok(objEmployeeDto);
        }

        [HttpPut("{Id}")]
        public async Task<ActionResult<bool>> PutAsync(int Id,[FromBody] EmployeeDto2 objEmployeeDto)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }

            Employee objEmployee = await _context.EmployeeDetails
                .FirstOrDefaultAsync(x => x.EmployeeId == Id);

            if (objEmployee == null)
            {
                return NotFound();
            }

            objEmployeeDto.EmployeeId = Id;

            Employee objModifiedEmployee =
                _mapper.Map<Employee>(objEmployeeDto);

            _context.Entry(objEmployee).CurrentValues.SetValues(objModifiedEmployee);

            int numRecordAffected = await _context.SaveChangesAsync();

            if (numRecordAffected >= 1)
            {
                return Ok(true);
            }

            return StatusCode(
                StatusCodes.Status500InternalServerError,
                false);
        }

        [HttpDelete("{Id}")]
        public async Task<ActionResult<bool>> DeleteAsync(int Id)
        {
            if (Id <= 0)
            {
                return BadRequest();
            }

            Employee objEmployee = await _context.EmployeeDetails
                .Include(e => e.WorkExperiences)
                .FirstOrDefaultAsync(x => x.EmployeeId == Id);

            if (objEmployee == null)
            {
                return NotFound();
            }

            _context.EmployeeDetails.Remove(objEmployee);

            int numRecordAffected = await _context.SaveChangesAsync();

            if (numRecordAffected >= 1)
            {
                return Ok(true);
            }

            return StatusCode(
                StatusCodes.Status500InternalServerError,
                false);
        }
    }
}