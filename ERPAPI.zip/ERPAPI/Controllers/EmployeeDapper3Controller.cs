﻿using AutoMapper;
using Dapper;
using ERPAPI.Data.Dapper;
using ERPAPI.Data.EF;
using ERPAPI.Data.Entities;
using ERPAPI.Dtos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Net;
using System.Net.Http.Headers;
using System.Reflection.Metadata;
namespace ERPAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeDapper3Controller : ControllerBase
    {
        private readonly EmployeeDapperContext _context;
        private readonly IMapper _mapper;
        public EmployeeDapper3Controller(EmployeeDapperContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }


        [HttpPost]
        public async Task<ActionResult<Boolean>> AddAsync([FromBody] EmployeeDto objEmployeeDto)
        {
            DataTable dtWorkExperiences = new DataTable();
            dtWorkExperiences.Columns.Add("EmployeeId", typeof(int));
            dtWorkExperiences.Columns.Add("Company", typeof(string));
            dtWorkExperiences.Columns.Add("NumberOfMonths", typeof(int));
            dtWorkExperiences.Columns.Add("LastDesignation", typeof(string));
            dtWorkExperiences.Columns.Add("Remarks", typeof(string));

            if (objEmployeeDto.WorkExperiences != null)
            {
                foreach (WorkExperienceDto oWorkExperience in objEmployeeDto.WorkExperiences)
                {
                    if (oWorkExperience.EmployeeId == 0)
                    {
                        oWorkExperience.EmployeeId = objEmployeeDto.EmployeeId;
                    }
                    dtWorkExperiences.Rows.Add(oWorkExperience.EmployeeId,oWorkExperience.Company, oWorkExperience.NumberOfMonths, oWorkExperience.LastDesignation, oWorkExperience.Remarks);
                }
            }

            DynamicParameters args = new DynamicParameters();
            args.Add("firstName", objEmployeeDto.FirstName);
            args.Add("lastName", objEmployeeDto.LastName);
            args.Add("dateofBirth", objEmployeeDto.DateofBirth);
            args.Add("personalEmail", objEmployeeDto.PersonalEmail);
            args.Add("mobileNumber", objEmployeeDto.MobileNumber);
            args.Add("postalAddress", objEmployeeDto.PostalAddress);
            args.Add("gender", objEmployeeDto.Gender);
            args.Add("country", objEmployeeDto.Country);
            args.Add("city", objEmployeeDto.City);
            args.Add("designation", objEmployeeDto.Designation);
            args.Add("basicPay", objEmployeeDto.BasicPay);
            args.Add("needTransportation", objEmployeeDto.NeedTransportation);
            args.Add("notes", objEmployeeDto.Notes ?? (object)DBNull.Value);
            args.Add("username", objEmployeeDto.Username);
            args.Add("password", objEmployeeDto.Password);
            args.Add("WorkExperiences", dtWorkExperiences.AsTableValuedParameter("[utt_WorkExperiences]"));


            using (IDbConnection dbConnection = _context.CreateConnection())
            {

                try
                {
                    int result = await dbConnection.ExecuteScalarAsync<int>("spInsertEmployeeDetails", args, commandType: CommandType.StoredProcedure);
                    if (result == 0)
                    {
                        return Ok(true);
                    }
                    else
                    {
                        return StatusCode(StatusCodes.Status500InternalServerError);
                    }

                }
                catch (Exception)
                {

                    return StatusCode(StatusCodes.Status500InternalServerError);
                }

            }
        }


        [HttpPut]
        [Route("{Id}")]
        public async Task<ActionResult<EmployeeDto>> PutAsync(int Id, [FromBody] EmployeeDto objEmployeeDto)
        {
            DataTable dtWorkExperiences = new DataTable();
            dtWorkExperiences.Columns.Add("EmployeeId", typeof(int));
            dtWorkExperiences.Columns.Add("Company", typeof(string));
            dtWorkExperiences.Columns.Add("NumberOfMonths", typeof(int));
            dtWorkExperiences.Columns.Add("LastDesignation", typeof(string));
            dtWorkExperiences.Columns.Add("Remarks", typeof(string));

            if (objEmployeeDto.WorkExperiences != null)
            {
                foreach (WorkExperienceDto oWorkExperience in objEmployeeDto.WorkExperiences)
                {
                    if (oWorkExperience.EmployeeId == 0)
                    {
                        oWorkExperience.EmployeeId = objEmployeeDto.EmployeeId;
                    }
                    dtWorkExperiences.Rows.Add(oWorkExperience.EmployeeId, oWorkExperience.Company, oWorkExperience.NumberOfMonths, oWorkExperience.LastDesignation, oWorkExperience.Remarks);
                }
            }

            DynamicParameters args = new DynamicParameters();
            args.Add("EmployeeId", Id);
            args.Add("firstName", objEmployeeDto.FirstName);
            args.Add("lastName", objEmployeeDto.LastName);
            args.Add("dateofBirth", objEmployeeDto.DateofBirth);
            args.Add("personalEmail", objEmployeeDto.PersonalEmail);
            args.Add("mobileNumber", objEmployeeDto.MobileNumber);
            args.Add("postalAddress", objEmployeeDto.PostalAddress);
            args.Add("gender", objEmployeeDto.Gender);
            args.Add("country", objEmployeeDto.Country);
            args.Add("city", objEmployeeDto.City);
            args.Add("designation", objEmployeeDto.Designation);
            args.Add("basicPay", objEmployeeDto.BasicPay);
            args.Add("needTransportation", objEmployeeDto.NeedTransportation);
            args.Add("notes", objEmployeeDto.Notes ?? (object)DBNull.Value);
            args.Add("username", objEmployeeDto.Username);
            args.Add("password", objEmployeeDto.Password);
            args.Add("WorkExperiences", dtWorkExperiences.AsTableValuedParameter("[utt_WorkExperiences]"));


            using (IDbConnection dbConnection = _context.CreateConnection())
            {

                try
                {
                    int result = await dbConnection.ExecuteScalarAsync<int>("spUpdateEmployeeDetails", args, commandType: CommandType.StoredProcedure);
                    if (result == 0)
                    {
                        return Ok(true);
                    }
                    else
                    {
                        if (result == -1)
                        {
                            return NotFound();
                        }
                        else
                        {
                            return StatusCode(StatusCodes.Status500InternalServerError);
                        }
                    }

                }
                catch (Exception)
                {

                    return StatusCode(StatusCodes.Status500InternalServerError);
                }

            }
        }

    
        [HttpDelete]
        [Route("{Id}")]
        public async Task<ActionResult<Boolean>> DeleteAsync(int Id)
        {
            DynamicParameters args = new DynamicParameters(new {});
            args.Add("@EmployeeId", Id);
            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                try
                {
                    int result = await dbConnection.ExecuteScalarAsync<int>("spDeleteEmployee", args, commandType: CommandType.StoredProcedure);

                    if (result == 0)
                    {
                        return Ok(true);
                    }
                    else
                    {
                        if (result == -1)
                        {
                            return NotFound();
                        }
                        else
                        {
                            return StatusCode(StatusCodes.Status500InternalServerError);
                        }
                    }
                }
                catch (Exception) 
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
                

            }
        }
    } }
    

