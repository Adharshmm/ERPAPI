﻿using ERPAPI.Data.EF;
using ERPAPI.Data.Entities;
using ERPAPI.Helpers;
using ERPAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace ERPAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly JWTSettings jWTSettings;
        private readonly UserManager<ApplicationUser> userManager;
        private readonly EmployeeDetailsDBContext EmployeeDetailsDBContext;

        public AccountController(JWTSettings jWTSettings, UserManager<ApplicationUser> userManager, EmployeeDetailsDBContext EmployeeDetailsDBContext)
        {
            this.jWTSettings = jWTSettings;
            this.userManager = userManager;
            this.EmployeeDetailsDBContext = EmployeeDetailsDBContext;
        }
        //    private IEnumerable<User> logins = new List<User>() {
        //    new User() {
        //        Id = Guid.NewGuid(),
        //        EmailId = "adminakp@gmail.com",
        //        UserName = "Admin",
        //        Password = "Admin",
        //        FirstName = "Admin",
        //        LastName = "Admin"
        //    },
        //    new User() {
        //        Id = Guid.NewGuid(),
        //        EmailId = "adminakp@gmail.com",
        //        UserName = "User1",
        //        Password = "Admin",
        //        FirstName = "Admin",
        //        LastName = "User"
        //     }
        //};

        //[HttpPost]
        //public IActionResult GetToken(UserLogin userLogin)
        //{
        //    try
        //    {
        //        var Token = new UserToken();
        //        var Valid = logins.Any(
        //            x => x.UserName.Equals(userLogin.UserName, StringComparison.OrdinalIgnoreCase) &&
        //            x.Password.Equals(userLogin.Password, StringComparison.Ordinal));

        //        if (Valid)
        //        {
        //            var user = logins.FirstOrDefault(
        //                x => x.UserName.Equals(userLogin.UserName, StringComparison.OrdinalIgnoreCase));

        //            Token = JwtHelper.GenTokenKey(new UserToken()
        //            {
        //                EmailId = user.EmailId,
        //                GuidId = Guid.NewGuid(),
        //                UserName = user.UserName,
        //                Id = user.Id,
        //            }, jWTSettings);
        //        }
        //        else
        //        {
        //            return BadRequest($"Invalid Credential");
        //        }
        //        return Ok(Token);
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //}
        [HttpPost]
        [Route("api/GetToken")]

        public async Task<IActionResult> GetToken(UserLogin userLogins)
        {
            try
            {
                var Token = new UserToken();
                var user = await userManager.FindByNameAsync(userLogins.UserName);
                if (user == null)
                {
                    return BadRequest("Invalid Credentials");
                }
                var Valid = await userManager.CheckPasswordAsync(user, userLogins.Password);
                if (Valid)
                {
                    var strToken = Guid.NewGuid().ToString();
                    var validity = DateTime.UtcNow.AddDays(15);
                    Token = Helpers.JwtHelper.GenTokenKey(new UserToken()
                    {
                        EmailId = user.Email,
                        GuidId = Guid.NewGuid(),
                        UserName = user.UserName,
                        Id = Guid.Parse(user.Id),
                        RefreshToken = strToken,

                    }, jWTSettings);
                    var tokenupdate = EmployeeDetailsDBContext.Users.Where(x => x.Id == user.Id).FirstOrDefault();
                    tokenupdate.RefreshToken = strToken;
                    tokenupdate.RefreshTokenValidity = validity;
                    EmployeeDetailsDBContext.Update(tokenupdate);
                    EmployeeDetailsDBContext.SaveChanges();
                    Token.RefreshToken = strToken;
                }
                else
                {
                    return BadRequest($"Invalid Credentials");
                }
                return Ok(Token);
            }
            catch (Exception)
            {
                throw;
            }
        }


        [HttpPost]
        [Route("api/RegisterUser")]

        public async Task<IActionResult> RegisterUser(User users)
        {
            try
            {
                var applicationUser = new ApplicationUser()
                {
                    UserName = users.UserName,
                    Email = users.EmailId,
                    Firstname = users.FirstName,
                    Lastname = users.LastName,
                    EmailConfirmed = true,
                    TwoFactorEnabled = false,
                    LockoutEnabled = false,

                };
                var result = await userManager.CreateAsync(applicationUser, users.Password);
                if (result.Succeeded)
                {
                    return Ok("User created");
                }
                else
                {
                    return BadRequest(result.Errors);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }



        [HttpPost]
        [Route("api/RefreshToken")]
        public async Task<IActionResult> RefreshToken(RefreshTokenModel userLogin)
        {
            try
            {
                var Token = new UserToken();

                var user = await userManager.FindByNameAsync(userLogin.UserName);

                if (user == null)
                {
                    return BadRequest("Invalid Credentials");
                }

                var Valid = EmployeeDetailsDBContext.Users
                    .Where(x => x.UserName == userLogin.UserName
                             && x.RefreshToken == userLogin.RefreshToken
                             && x.RefreshTokenValidity > DateTime.UtcNow)
                    .Count() > 0;

                if (Valid)
                {
                    var strToken = Guid.NewGuid().ToString();
                    var validity = DateTime.UtcNow.AddDays(15);

                    Token = Helpers.JwtHelper.GenTokenKey(new UserToken()
                    {
                        EmailId = user.Email,
                        GuidId = Guid.NewGuid(),
                        UserName = user.UserName,
                        Id = Guid.Parse(user.Id),
                        RefreshToken = strToken
                    }, jWTSettings);

                    user.RefreshToken = strToken;
                    user.RefreshTokenValidity = validity;

                    EmployeeDetailsDBContext.Update(user);

                    await EmployeeDetailsDBContext.SaveChangesAsync();
                }
                else
                {
                    return BadRequest("Invalid Credentials");
                }

                return Ok(Token);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
    

