﻿namespace ERPAPI.Models
{
    public class User
    {

               public String FirstName { get; set; }
               public String LastName {get;set;}
               public string EmailId { get; set; }
               public string UserName {  get; set; }    
               public string Password {  get; set; }
               public Guid Id {  get; set; }
    }
}
