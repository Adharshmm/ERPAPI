using ERPAPI.Data.Dapper;
using ERPAPI.Data.EF;
using ERPAPI.Dtos;
using ERPAPI.Extensions;
using ERPAPI.Services.BL;
using ERPAPI.Services.DB.EF;
using ERPAPI.Services.DB.Interfaces;
using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddJWTTokenServices(builder.Configuration);
builder.Services.AddIdentityServices(builder.Configuration);


builder.Services.AddControllers();

builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddValidatorsFromAssemblyContaining<EmployeeDto3Validator>();

// Add services to the container.
builder.Services.AddDbContext<EmployeeDetailsDBContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("EmployeeDetailsDB"));
}
);

builder.Services.AddAutoMapper(typeof(Program));
builder.Services.AddSingleton<EmployeeDapperContext>();

builder.Services.AddScoped<IEmployeeDA, EmployeeDA2>();
builder.Services.AddScoped<IEmployee2DA, EmployeeDA>();
builder.Services.AddScoped<IEmployeeLookupDA, ERPAPI.Services.DB.Dapper.EmployeeDA>();
builder.Services.AddScoped<IProjectDA, ERPAPI.Services.DB.Dapper.ProjectDA>();

builder.Services.AddScoped<EmployeeBL2>();
builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Description = "JWT Authorization header using the Bearer scheme"
    });
    options.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[]{}
        }
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();
app.UseAuthorization();

app.MapControllers();

app.Run();
