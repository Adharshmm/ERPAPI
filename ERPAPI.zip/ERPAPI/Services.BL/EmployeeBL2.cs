﻿using AutoMapper;
using ERPAPI.Data.Entities;
using ERPAPI.Dtos;
using ERPAPI.Services.DB.Common;
using ERPAPI.Services.DB.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace ERPAPI.Services.BL
{
    public class EmployeeBL2 : BaseBL
    {

       

        private const decimal DA_RATE = 0.5m;
        private const decimal CCA_AMOUNT = 1000.00m;
        private const decimal PROJECT_ALLOWANCE_RATE = 0.8m;
        private const decimal PHONE_ALLOWANCE_AMOUNT = 2000.00m;

        private const decimal PROFESSIONAL_TAX_THRESHOLD = 6500.00m;
        private const decimal PROFESSIONAL_TAX_AMOUNT = 250.00m;

        private const decimal INCOME_TAX_SLAB1_LOWER = 750000.00m;
        private const decimal INCOME_TAX_SLAB1_UPPER = 1000000.00m;
        private const decimal INCOME_TAX_SLAB1_RATE = 0.1m;

        private const decimal INCOME_TAX_SLAB2_UPPER = 1500000.00m;
        private const decimal INCOME_TAX_SLAB2_BASE = 25000.00m;
        private const decimal INCOME_TAX_SLAB2_RATE = 0.2m;

        private const decimal INCOME_TAX_SLAB3_BASE = 125000.00m;
        private const decimal INCOME_TAX_SLAB3_RATE = 0.3m;

        private readonly IEmployee2DA _employee2DA;
        private readonly IMapper _mapper;
        public EmployeeBL2(IEmployee2DA employeeDA, IMapper mapper)
        {
            _employee2DA = employeeDA;
            _mapper = mapper;
        }

        List<string> designations = new List<string> { "Team Leader", "Project Manager", "Vice President" };

        private const int MONTHS = 12;

        public EmployeeBLDto GetSalaryDetails(EmployeeBLDto objEmployeeDto)
        {
            decimal DA = CalculateDA(objEmployeeDto.BasicPay);
            decimal CCA = CCA_AMOUNT;
            bool eligibleForExtras = EligiblityForProjectAndPhoneAllowance(objEmployeeDto.Designation);
            decimal projectAllowance = CalculateProjectAllowance(objEmployeeDto.BasicPay, eligibleForExtras);
            decimal phoneAllowance = CalculatePhoneAllowance(eligibleForExtras);
            decimal totalSalary = CalculateTotalSalary(objEmployeeDto.BasicPay, DA, projectAllowance, CCA, phoneAllowance);
            decimal yearlyTotalSalary = totalSalary * MONTHS;
            decimal professionalTax = CalculateProfessionalTax(objEmployeeDto.BasicPay);
            decimal incomeTax = CalculateIncomeTax(yearlyTotalSalary);
            decimal netSalary = CalculateNetSalary(totalSalary, professionalTax, incomeTax);

            objEmployeeDto.DA = DA;
            objEmployeeDto.CCA = CCA;
            objEmployeeDto.ProjectAllowance = projectAllowance;
            objEmployeeDto.PhoneAllowance = phoneAllowance;
            objEmployeeDto.TotalSalary = totalSalary;
            objEmployeeDto.ProfessionalTax = professionalTax;
            objEmployeeDto.IncomeTax = incomeTax;
            objEmployeeDto.NetSalary = netSalary;

            return objEmployeeDto;
        }

        public List<EmployeeBLDto> GetSalaryDetailsList(List<EmployeeBLDto> employeeDetailsDtos)
        {
            foreach (EmployeeBLDto oEmployeeDetailsDto in employeeDetailsDtos)
            {
                GetSalaryDetails(oEmployeeDetailsDto);
            }
            return employeeDetailsDtos;
        }



        private decimal CalculateDA(decimal basicPay)
        {
            return basicPay * DA_RATE;
        }

        private bool EligiblityForProjectAndPhoneAllowance(string designation)
        {
            return designations.Contains(designation);
        }

        private decimal CalculateProjectAllowance(decimal basicPay, bool eligible)
        {
            return eligible ? basicPay * PROJECT_ALLOWANCE_RATE : 0;
        }

        private decimal CalculatePhoneAllowance(bool eligible)
        {
            return eligible ? PHONE_ALLOWANCE_AMOUNT : 0;
        }

        private decimal CalculateTotalSalary(decimal basicPay, decimal DA, decimal CCA, decimal projectAllowance, decimal phoneAllowance)
        {
            return basicPay + DA + CCA + projectAllowance + phoneAllowance;
        }

        private decimal CalculateProfessionalTax(decimal basicPay)
        {
            return basicPay > PROFESSIONAL_TAX_THRESHOLD ? PROFESSIONAL_TAX_AMOUNT : 0;
        }

        private decimal CalculateIncomeTax(decimal yearlyTotalSalary)
        {
            if (yearlyTotalSalary > INCOME_TAX_SLAB2_UPPER)
                return INCOME_TAX_SLAB3_BASE + (yearlyTotalSalary - INCOME_TAX_SLAB2_UPPER) * INCOME_TAX_SLAB3_RATE;

            if (yearlyTotalSalary > INCOME_TAX_SLAB1_UPPER)
                return INCOME_TAX_SLAB2_BASE + (yearlyTotalSalary - INCOME_TAX_SLAB1_UPPER) * INCOME_TAX_SLAB2_RATE;

            if (yearlyTotalSalary > INCOME_TAX_SLAB1_LOWER)
                return (yearlyTotalSalary - INCOME_TAX_SLAB1_LOWER) * INCOME_TAX_SLAB1_RATE;

            return 0;
        }

        private decimal CalculateNetSalary(decimal TotalSalary, decimal professionalTax, decimal incomeTax)
        {
            decimal monthlyIncomeTax = incomeTax / MONTHS;
            decimal netSalary = TotalSalary - professionalTax - monthlyIncomeTax;
            return Math.Round(netSalary,2);
        }


        public async Task<int> InsertAsync(Employee oEmployee)
        {
            int numRecordAffected = await _employee2DA.Insert(oEmployee);
            return numRecordAffected;
        }

        public async Task<List<EmployeeBLDto>> GetList()

        {
            List<Employee> employees = await _employee2DA.GetList();
            List<EmployeeBLDto> employeesBlDto = _mapper.Map<List<Employee>, List<EmployeeBLDto>>(employees);
            return (GetSalaryDetailsList(employeesBlDto));
        }

        public Boolean IsEmployeeListNull()
        {
            return _employee2DA.IsEmployeeListNull();
        }

        public async Task<EmployeeBLDto> GetById(int Id)
        {
            Employee objEmployee = await _employee2DA.GetById(Id);
            if (objEmployee == null) {
                return null;
               }
            EmployeeBLDto employeeBlDto = _mapper.Map<EmployeeBLDto>(objEmployee);
            return GetSalaryDetails(employeeBlDto);
        }

        public async Task<int> EmpUpdate(Employee oemployee)
        {
            return await _employee2DA.EmpUpdate(oemployee);
        }

        public async Task<int> DeleteEmp(int Id)
        {
            var employee = await _employee2DA.GetById(Id);
            if (employee == null) 
            {
                return 0;
            }

            return await _employee2DA.DeleteEmp(employee);
        }

    }
}
