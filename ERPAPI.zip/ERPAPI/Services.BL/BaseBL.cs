﻿namespace ERPAPI.Services.BL
{
    public class BaseBL
    {
    }
}
