﻿namespace ERPAPI.Dtos
{
    public class DtoBase
    {
    }
}
