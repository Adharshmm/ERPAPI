﻿using FluentValidation;

namespace ERPAPI.Dtos
{
    public class EmployeeDto3Validator : AbstractValidator<EmployeeDto3>
    {
        public EmployeeDto3Validator()
        {
            RuleFor(x => x.FirstName)
                .NotEmpty()
                .MinimumLength(3)
                .MaximumLength(50);

            RuleFor(x => x.LastName)
                .NotEmpty()
                .MinimumLength(3)
                .MaximumLength(50);

            RuleFor(x => x.DateofBirth)
                .NotNull()
                .Must(BeAtLeast18YearsOld)
                .WithMessage("Employee must be at least 18 years old.");

            RuleFor(x => x.PersonalEmail)
                .NotEmpty()
                .EmailAddress();

            RuleFor(x => x.MobileNumber)
                .NotEmpty()
                .Matches(@"^[6-9]\d{9}$")
                .WithMessage("Mobile Number must be a valid mobile number.");

            RuleFor(x => x.PostalAddress)
                .NotNull()
                .MaximumLength(250);

            RuleFor(x => x.Gender)
                .InclusiveBetween(1, 3)
                .WithMessage("Gender must be 1, 2 or 3.");

            RuleFor(x => x.Country)
                .NotEmpty()
                .Must(x =>
                    x == "India" ||
                    x == "United Kingdom" ||
                    x == "United States of America")
                .WithMessage("Country must be India, United Kingdom or United States of America.");

            RuleFor(x => x.City)
                .NotEmpty()
                .MinimumLength(3)
                .MaximumLength(50);

            RuleFor(x => x.BasicPay)
                .InclusiveBetween(3000, 50000)
                .WithMessage("Basic Pay must be between 3000 and 50000.");

            RuleFor(x => x.Username)
                .NotEmpty()
                .Matches(@"^[a-zA-Z0-9]+$")
                .WithMessage("Username must contain only alpha-numeric characters.");

            RuleFor(x => x.Password)
                .NotEmpty()
                .Matches(@"^(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z0-9]).+$")
                .WithMessage("Password must contain at least one uppercase letter, one digit and one special character.");

            RuleForEach(x => x.WorkExperiences)
                .SetValidator(new WorkExperienceDto2Validator());
        }

        private bool BeAtLeast18YearsOld(DateTime dateOfBirth)
        {
            DateTime minimumDate = DateTime.Today.AddYears(-18);

            return dateOfBirth <= minimumDate;
        }
    }
}