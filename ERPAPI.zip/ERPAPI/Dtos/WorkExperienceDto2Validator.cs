﻿using FluentValidation;

namespace ERPAPI.Dtos
{
    public class WorkExperienceDto2Validator : AbstractValidator<WorkExperienceDto2>
    {
        public WorkExperienceDto2Validator()
        {
            RuleFor(x => x.Company)
                .NotEmpty()
                .MaximumLength(50);

            RuleFor(x => x.NumberOfMonths)
                .GreaterThanOrEqualTo(6);

            RuleFor(x => x.LastDesignation)
                .NotEmpty()
                .MaximumLength(50);
        }
    }
}