﻿using ERPAPI.Data.Entities;
using System.ComponentModel.DataAnnotations;

namespace ERPAPI.Dtos
{
    public class EmployeeDto3 : DtoBase
    {
       public int EmployeeId { get; set; }

       public string FirstName { get; set; }

       public string LastName { get; set; }

       public DateTime DateofBirth { get; set; }

       public string PersonalEmail { get; set; }

        public string MobileNumber { get; set; }

        public string PostalAddress { get; set; }

        public int Gender { get; set; }

        public string Country { get; set; }

        public string City { get; set; }

        public string Designation { get; set; }

        public decimal BasicPay { get; set; }

        public bool NeedTransportation { get; set; }

        public string Notes { get; set; }

        public string Username { get; set; }

        public  string Password { get; set; }


        public List<WorkExperienceDto2> WorkExperiences { get; set; }
    }
}
