﻿using System.ComponentModel.DataAnnotations;

namespace ERPAPI.Dtos
{
    public class MinimumAgeAttribute : ValidationAttribute
    {
        private readonly int _minimumAge;

        public MinimumAgeAttribute(int minimumAge)
        {
            _minimumAge = minimumAge;
        }

        protected override ValidationResult IsValid(object value,ValidationContext validationContext)
        {
            if (value == null)
            {
                return new ValidationResult("Date of Birth is required.");
            }

            DateTime dateOfBirth = (DateTime)value;

            DateTime minimumDate = DateTime.Today.AddYears(-_minimumAge);

            if (dateOfBirth > minimumDate)
            {
                return new ValidationResult(
                    "Employee must be at least 18 years old.");
            }

            return ValidationResult.Success;
        }
    }
}