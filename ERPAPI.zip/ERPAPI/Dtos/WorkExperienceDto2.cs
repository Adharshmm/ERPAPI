﻿using ERPAPI.Data.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace ERPAPI.Dtos
{
    public class WorkExperienceDto2:DtoBase
    {
        public int WorkExperienceId { get; set; }
        public int EmployeeId { get; set; }
        public string Company { get; set; }
        public int NumberOfMonths { get; set; }
        public string LastDesignation { get; set; }
        public string Remarks { get; set; }

    }
}
