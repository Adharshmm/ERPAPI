﻿using System.ComponentModel.DataAnnotations;

namespace ERPAPI.Dtos
{
    public class EmployeeDto2 : DtoBase
    {
        public int EmployeeId { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 3)]
        public string FirstName { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 3)]
        public string LastName { get; set; }

        [Required]
        [MinimumAge(18)]
        public DateTime DateofBirth { get; set; }

        [Required]
        [EmailAddress]
        public string PersonalEmail { get; set; }

        [Required]
        [Phone]
        public string MobileNumber { get; set; }

        [Required(AllowEmptyStrings = true)]
        [StringLength(250)]
        public string PostalAddress { get; set; }

        [Required]
        [Range(1, 3)]
        public int Gender { get; set; }

        [Required]
        [RegularExpression(
            "^(India|United Kingdom|United States of America)$",
            ErrorMessage = "Country must be India, United Kingdom or United States of America."
        )]
        public string Country { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 3)]
        public string City { get; set; }

        public string Designation { get; set; }

        [Required]
        [Range(3000, 50000)]
        public decimal BasicPay { get; set; }

        public bool NeedTransportation { get; set; }

        public string Notes { get; set; }

        [Required]
        [RegularExpression(
            "^[a-zA-Z0-9]+$",
            ErrorMessage = "Username must contain only alpha-numeric characters."
        )]
        public string Username { get; set; }

        [Required]
        [RegularExpression(
            "^(?=.*[A-Z])(?=.*\\d)(?=.*[^a-zA-Z0-9]).+$",
            ErrorMessage = "Password must contain at least one uppercase letter, one digit and one special character."
        )]
        public string Password { get; set; }

        public List<WorkExperienceDto2> WorkExperiences { get; set; }
    }
}
