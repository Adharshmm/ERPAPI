﻿namespace ERPAPI.Dtos
{
    public class ProjectDto:DtoBase
    {
        public int ProjectId { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public int ProjectManagerId { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime? TentativeClosingDate { get; set; }

        public int AccountManagerId { get; set; }
    }
}
