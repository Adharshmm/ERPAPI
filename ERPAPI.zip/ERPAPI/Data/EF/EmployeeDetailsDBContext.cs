﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using ERPAPI.Data.Entities;
namespace ERPAPI.Data.EF
{
    public class EmployeeDetailsDBContext: IdentityDbContext<ApplicationUser>
    {
        public EmployeeDetailsDBContext(DbContextOptions<EmployeeDetailsDBContext> options) : base(options)
        {

        }
        public DbSet<Employee> EmployeeDetails {  get; set; }
        public DbSet<WorkExperience> WorkExperiences { get; set; }
        public DbSet<ApplicationUser> ApplicationUsers { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>()
                .ToTable("EmployeeDetails", t => t.ExcludeFromMigrations())
                .Property(e => e.BasicPay)
                .HasPrecision(18, 2);
            modelBuilder.Entity<WorkExperience>()
                .ToTable("WorkExperiences", t => t.ExcludeFromMigrations());
            modelBuilder.Entity<IdentityUserLogin<Guid>>().HasNoKey();
            modelBuilder.Entity<IdentityUserClaim<Guid>>().HasNoKey();
            modelBuilder.Entity<IdentityUserToken<Guid>>().HasNoKey();
            modelBuilder.Entity<IdentityRoleClaim<Guid>>().HasNoKey();
            base.OnModelCreating(modelBuilder);
        }

    }
}
