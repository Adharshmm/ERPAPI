﻿using System.ComponentModel.DataAnnotations;

namespace ERPAPI.Data.Entities
{
    public class Project:EntityBase
    {
        [Key]
        public int ProjectId { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public int ProjectManagerId { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime? TentativeClosingDate { get; set; }

        public int AccountManagerId { get; set; }
    }
}
