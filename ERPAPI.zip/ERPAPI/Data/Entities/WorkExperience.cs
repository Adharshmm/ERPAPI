﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ERPAPI.Data.Entities
{
    public class WorkExperience : EntityBase
    {
        [Key]
        public int WorkExperienceId { get; set; }
        public int EmployeeId { get; set; }
        [ForeignKey(nameof(WorkExperience.EmployeeId))]
        public string Company { get; set; }
        public int NumberOfMonths { get; set; }
        public string LastDesignation { get; set; }
        public string Remarks { get; set; }
        public Employee Employee { get; set; }  
    }
}
