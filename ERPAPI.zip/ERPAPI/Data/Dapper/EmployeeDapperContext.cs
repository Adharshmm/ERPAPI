﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace ERPAPI.Data.Dapper
{
    public class EmployeeDapperContext
    {
        private readonly IConfiguration _configuration;
        private readonly string? _connectionString;

        public EmployeeDapperContext(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("EmployeeDetailsDB");
        }

        public IDbConnection CreateConnection()=> new SqlConnection(_connectionString);
    }
}
