﻿using AutoMapper;
using ERPAPI.Data.Entities;
using ERPAPI.Dtos;
namespace ERPAPI
{
    public class AutomapperProfile : Profile
    {
        public AutomapperProfile()
        {
            CreateMap<EmployeeDto, Employee>();
            CreateMap<Employee, EmployeeDto>();

            CreateMap<WorkExperienceDto, WorkExperience>();
            CreateMap<WorkExperience, WorkExperienceDto>();

            CreateMap<WorkExperienceDto2, WorkExperience>();
            CreateMap<WorkExperience, WorkExperienceDto2>();

            CreateMap<EmployeeBLDto, Employee>();
            CreateMap<Employee, EmployeeBLDto>();

            CreateMap<EmployeeDto2, Employee>();
            CreateMap<Employee, EmployeeDto2>();
        }
    }
}
