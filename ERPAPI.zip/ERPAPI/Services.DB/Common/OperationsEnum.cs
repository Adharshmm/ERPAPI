﻿namespace ERPAPI.Services.DB.Common
{
    public enum OperationStatus
    {
        Success,
        Failure,
        NotFound,
        UnknownException

    }

    public enum OperationPerformed
    {
        Insert,
        Update, 
        Delete
    }
}
