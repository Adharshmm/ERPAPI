﻿namespace ERPAPI.Services.DB.Common
{
    public class ServiceResponse
    {
        public OperationStatus Status { get; set; }
        public int RecordsAffected { get; set; }
        public string? ExecptionMessage { get; set; }
        public string ResourceName { get; set; }
        public OperationPerformed OperationPerformed { get; set; }

    }

}
