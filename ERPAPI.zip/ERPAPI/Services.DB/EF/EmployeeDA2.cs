﻿using AutoMapper;
using ERPAPI.Data.Dapper;
using ERPAPI.Data.EF;
using ERPAPI.Data.Entities;
using ERPAPI.Services.DB.Common;
using ERPAPI.Services.DB.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ERPAPI.Services.DB.EF
{
    public class EmployeeDA2 : DABase, IEmployeeDA
    {
        private EmployeeDetailsDBContext _context;

        public EmployeeDA2(EmployeeDetailsDBContext context)
        {
            _context = context;
        }


        public async Task<ServiceResponse> Insert(Employee oEmployee)
        {
            ServiceResponse result = new ServiceResponse();
            try
            {
                _context.EmployeeDetails.Add(oEmployee);
                int numRecordAffected = await _context.SaveChangesAsync();
                if (numRecordAffected > 0)
                {
                    result.Status = OperationStatus.Success;
                    result.RecordsAffected = numRecordAffected;
                    result.ResourceName = "EmployeeDetails";
                    result.OperationPerformed = OperationPerformed.Insert;
                    return result;
                }
                else
                {
                    result.Status = OperationStatus.Failure;
                    result.RecordsAffected = numRecordAffected;
                    result.ResourceName = "EmployeeDetails";
                    result.OperationPerformed = OperationPerformed.Insert;
                    return result;
                }
            }
            catch (Exception err)
            {
                result.Status = OperationStatus.UnknownException;
                result.RecordsAffected = 0;
                result.ResourceName = "EmployeeDetails";
                result.OperationPerformed = OperationPerformed.Insert;
                result.ExecptionMessage = err.Message;
                return result;
            }
            ;
            
        }

        public async Task<List<Employee>> GetList()
        {
            return await _context.EmployeeDetails.Include(p => p.WorkExperiences).ToListAsync();
        }

        public Boolean IsEmployeeListNull()
        {
            return _context.EmployeeDetails.Any();
        }

        public async Task<Employee> GetById(int Id)
        {
            return await _context.EmployeeDetails.Where(x => x.EmployeeId == Id).Include(e => e.WorkExperiences).AsNoTracking().FirstOrDefaultAsync();
        }

        public async Task<ServiceResponse> EmpUpdate(Employee oemployee)
        {
            ServiceResponse result = new ServiceResponse();
            try 
            {
                _context.EmployeeDetails.Update(oemployee);
                int numRecordAffected = await _context.SaveChangesAsync();
                if (numRecordAffected > 0)
                {
                    result.Status = OperationStatus.Success;
                    result.RecordsAffected = numRecordAffected;
                    result.ResourceName = "EmployeeDetails";
                    result.OperationPerformed = OperationPerformed.Update;
                    return result;
                }
                else
                {
                    result.Status = OperationStatus.Failure;
                    result.RecordsAffected = numRecordAffected;
                    result.ResourceName = "EmployeeDetails";
                    result.OperationPerformed = OperationPerformed.Update;
                    return result;
                }

            } 
            catch (Exception err) 
            {
                result.Status = OperationStatus.UnknownException;
                result.RecordsAffected = 0;
                result.ResourceName = "EmployeeDetails";
                result.OperationPerformed = OperationPerformed.Update;
                result.ExecptionMessage = err.Message;
                return result;
            }
            
        }

        public async Task<ServiceResponse> DeleteEmp(Employee oEmployee)
        {
           
            ServiceResponse result = new ServiceResponse();
            try
            {
                _context.EmployeeDetails.Remove(oEmployee);
                int numRecordAffected = await _context.SaveChangesAsync();
                if (numRecordAffected > 0)
                {
                    result.Status = OperationStatus.Success;
                    result.RecordsAffected = numRecordAffected;
                    result.ResourceName = "EmployeeDetails";
                    result.OperationPerformed = OperationPerformed.Delete;
                    return result;
                }
                else
                {
                    result.Status = OperationStatus.Failure;
                    result.RecordsAffected = numRecordAffected;
                    result.ResourceName = "EmployeeDetails";
                    result.OperationPerformed = OperationPerformed.Delete;
                    return result;
                }

            }
            catch (Exception err)
            {
                result.Status = OperationStatus.UnknownException;
                result.RecordsAffected = 0;
                result.ResourceName = "EmployeeDetails";
                result.OperationPerformed = OperationPerformed.Delete;
                result.ExecptionMessage = err.Message;
                return result;
            }
        }

    }
}
