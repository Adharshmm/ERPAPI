﻿using AutoMapper;
using ERPAPI.Data.Dapper;
using ERPAPI.Data.EF;
using ERPAPI.Data.Entities;
using ERPAPI.Services.DB.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ERPAPI.Services.DB.EF
{
    public class EmployeeDA : DABase,IEmployee2DA
    {
        private EmployeeDetailsDBContext _context;

        public EmployeeDA(EmployeeDetailsDBContext context)
        {
            _context = context;
        }


        public async Task<int> Insert(Employee oEmployee)
        {
            _context.EmployeeDetails.Add(oEmployee);
            int numRecordAffected = await _context.SaveChangesAsync();
            return numRecordAffected;
        }

        public async Task<List<Employee>> GetList()
        {
            return await _context.EmployeeDetails.Include(p => p.WorkExperiences).ToListAsync();
        }

        public Boolean IsEmployeeListNull()
        {
            return _context.EmployeeDetails.Any();
        }

        public async Task<Employee> GetById(int Id)
        {
            return await _context.EmployeeDetails.Where(x => x.EmployeeId == Id).Include(e => e.WorkExperiences).AsNoTracking().FirstOrDefaultAsync();
        }

        public async Task<int> EmpUpdate(Employee oemployee)
        {
            _context.EmployeeDetails.Update(oemployee);
            return await _context.SaveChangesAsync();
        }

        public async Task<int> DeleteEmp(Employee oEmployee)
        {
            _context.EmployeeDetails.Remove(oEmployee);
            return await _context.SaveChangesAsync();
        }

    }
}
