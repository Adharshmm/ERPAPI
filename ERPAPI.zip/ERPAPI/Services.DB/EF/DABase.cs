﻿namespace ERPAPI.Services.DB.EF
{
    public class DABase
    {
    }
}
