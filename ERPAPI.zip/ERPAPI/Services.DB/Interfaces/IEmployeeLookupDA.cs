﻿using ERPAPI.Data.Entities;

public interface IEmployeeLookupDA
{
    Task<List<Employee>> GetProjectManagers();
    Task<List<Employee>> GetVicePresidents();
}