﻿using ERPAPI.Data.Entities;
using ERPAPI.Services.DB.Common;

namespace ERPAPI.Services.DB.Interfaces
{
    public interface IEmployee2DA
    {
        Task<int> DeleteEmp(Employee oEmployee);
        Task<int> EmpUpdate(Employee oemployee);
        Task<Employee> GetById(int Id);
        Task<List<Employee>> GetList();
        Task<int> Insert(Employee oEmployee);
        bool IsEmployeeListNull();
    }
}