﻿using ERPAPI.Data.Entities;
using ERPAPI.Services.DB.Common;

namespace ERPAPI.Services.DB.Interfaces
{
    public interface IEmployeeDA
    {
        Task<ServiceResponse> DeleteEmp(Employee oEmployee);
        Task<ServiceResponse> EmpUpdate(Employee oemployee);
        Task<Employee> GetById(int Id);
        Task<List<Employee>> GetList();
        Task<ServiceResponse> Insert(Employee oEmployee);
       
        bool IsEmployeeListNull();
    }
}