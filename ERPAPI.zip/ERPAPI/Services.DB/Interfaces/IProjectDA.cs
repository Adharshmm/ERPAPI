﻿using ERPAPI.Data.Entities;
using ERPAPI.Services.DB.Common;

namespace ERPAPI.Services.DB.Interfaces
{
    public interface IProjectDA
    {
        Task<ServiceResponse> Insert(Project project);
        Task<Project?> GetById(int id);
        Task<List<Project>> GetList();
        Task<ServiceResponse> Update(int Id,Project project);
        Task<ServiceResponse> Delete(int id);
        Task<List<Project>> GetPagedList(int pageNumber, int pageSize);
        Task<List<Project>> GetByProjectManager(int projectManagerId);
    }
}