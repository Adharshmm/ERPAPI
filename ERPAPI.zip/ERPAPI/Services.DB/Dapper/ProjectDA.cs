﻿using Dapper;
using ERPAPI.Data.Dapper;
using ERPAPI.Data.Entities;
using ERPAPI.Services.DB.Common;
using ERPAPI.Services.DB.Drapper;
using ERPAPI.Services.DB.Interfaces;
using System.Data;

namespace ERPAPI.Services.DB.Dapper
{
    public class ProjectDA : DABase, IProjectDA
    {
        private readonly EmployeeDapperContext _context;

        public ProjectDA(EmployeeDapperContext context)
        {
            _context = context;
        }

        public async Task<ServiceResponse> Insert(Project project)
        {
            ServiceResponse result = new ServiceResponse();

            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                dbConnection.Open();

                IDbTransaction transaction = dbConnection.BeginTransaction();

                try
                {
                    string projectManagerValidation = @"
                        SELECT COUNT(1)
                        FROM EmployeeDetails
                        WHERE EmployeeId = @ProjectManagerId
                        AND Designation IN
                        (
                            'Team Leader',
                            'Project Leader',
                            'Project Manager',
                            'Vice President'
                        )";

                    int projectManagerCount =
                        await dbConnection.ExecuteScalarAsync<int>(
                            projectManagerValidation,
                            new
                            {
                                project.ProjectManagerId
                            },
                            transaction);

                    if (projectManagerCount == 0)
                    {
                        transaction.Rollback();

                        result.Status = OperationStatus.Failure;
                        result.RecordsAffected = 0;
                        result.ResourceName = "Projects";
                        result.OperationPerformed = OperationPerformed.Insert;
                        result.ExecptionMessage = "Invalid Project Manager";

                        return result;
                    }

                    string accountManagerValidation = @"
                        SELECT COUNT(1)
                        FROM EmployeeDetails
                        WHERE EmployeeId = @AccountManagerId
                        AND Designation = 'Vice President'";

                    int accountManagerCount =
                        await dbConnection.ExecuteScalarAsync<int>(
                            accountManagerValidation,
                            new
                            {
                                project.AccountManagerId
                            },
                            transaction);

                    if (accountManagerCount == 0)
                    {
                        transaction.Rollback();

                        result.Status = OperationStatus.Failure;
                        result.RecordsAffected = 0;
                        result.ResourceName = "Projects";
                        result.OperationPerformed = OperationPerformed.Insert;
                        result.ExecptionMessage =
                            "Account Manager must be a Vice President";

                        return result;
                    }

                    string query = @"
                        INSERT INTO Projects
                        (
                            Name,
                            Description,
                            ProjectManagerId,
                            StartDate,
                            TentativeClosingDate,
                            AccountManagerId
                        )
                        VALUES
                        (
                            @Name,
                            @Description,
                            @ProjectManagerId,
                            @StartDate,
                            @TentativeClosingDate,
                            @AccountManagerId
                        )";

                    int numRecordsAffected =
                        await dbConnection.ExecuteAsync(
                            query,
                            project,
                            transaction);

                    if (numRecordsAffected == 1)
                    {
                        transaction.Commit();

                        result.Status = OperationStatus.Success;
                        result.RecordsAffected = numRecordsAffected;
                        result.ResourceName = "Projects";
                        result.OperationPerformed =
                            OperationPerformed.Insert;

                        return result;
                    }

                    transaction.Rollback();

                    result.Status = OperationStatus.Failure;
                    result.RecordsAffected = numRecordsAffected;
                    result.ResourceName = "Projects";
                    result.OperationPerformed =
                        OperationPerformed.Insert;

                    return result;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();

                    result.Status = OperationStatus.UnknownException;
                    result.RecordsAffected = 0;
                    result.ResourceName = "Projects";
                    result.OperationPerformed =
                        OperationPerformed.Insert;
                    result.ExecptionMessage = ex.Message;

                    return result;
                }
                finally
                {
                    transaction.Dispose();
                }
            }
        }


        public async Task<Project?> GetById(int id)
        {
            string query = @"
                SELECT
                    ProjectId,
                    Name,
                    Description,
                    ProjectManagerId,
                    StartDate,
                    TentativeClosingDate,
                    AccountManagerId
                FROM Projects
                WHERE ProjectId = @Id";

            using (IDbConnection dbConnection =
                   _context.CreateConnection())
            {
                return await dbConnection
                    .QuerySingleOrDefaultAsync<Project>(
                        query,
                        new
                        {
                            Id = id
                        });
            }
        }


        public async Task<List<Project>> GetList()
        {
            string query = @"
                SELECT
                    ProjectId,
                    Name,
                    Description,
                    ProjectManagerId,
                    StartDate,
                    TentativeClosingDate,
                    AccountManagerId
                FROM Projects";

            using (IDbConnection dbConnection =
                   _context.CreateConnection())
            {
                IEnumerable<Project> projects =
                    await dbConnection.QueryAsync<Project>(query);

                return projects.ToList();
            }
        }


        public async Task<ServiceResponse> Update(int Id, Project project)
        {
            ServiceResponse result = new ServiceResponse();

            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                dbConnection.Open();

                IDbTransaction transaction = dbConnection.BeginTransaction();

                try
                {
                    string projectManagerValidation = @"
                SELECT COUNT(1)
                FROM EmployeeDetails
                WHERE EmployeeId = @ProjectManagerId
                AND Designation IN
                (
                    'Team Leader',
                    'Project Leader',
                    'Project Manager',
                    'Vice President'
                )";

                    DynamicParameters projectManagerParameters = new DynamicParameters();
                    projectManagerParameters.Add("ProjectManagerId", project.ProjectManagerId);

                    int projectManagerCount =
                        await dbConnection.ExecuteScalarAsync<int>(
                            projectManagerValidation,
                            projectManagerParameters,
                            transaction);

                    if (projectManagerCount == 0)
                    {
                        transaction.Rollback();

                        result.Status = OperationStatus.Failure;
                        result.RecordsAffected = 0;
                        result.ResourceName = "Projects";
                        result.OperationPerformed = OperationPerformed.Update;
                        result.ExecptionMessage = "Invalid Project Manager";

                        return result;
                    }

                    string accountManagerValidation = @"
                SELECT COUNT(1)
                FROM EmployeeDetails
                WHERE EmployeeId = @AccountManagerId
                AND Designation = 'Vice President'";

                    DynamicParameters accountManagerParameters = new DynamicParameters();
                    accountManagerParameters.Add("AccountManagerId", project.AccountManagerId);

                    int accountManagerCount =
                        await dbConnection.ExecuteScalarAsync<int>(
                            accountManagerValidation,
                            accountManagerParameters,
                            transaction);

                    if (accountManagerCount == 0)
                    {
                        transaction.Rollback();

                        result.Status = OperationStatus.Failure;
                        result.RecordsAffected = 0;
                        result.ResourceName = "Projects";
                        result.OperationPerformed = OperationPerformed.Update;
                        result.ExecptionMessage = "Account Manager must be a Vice President";

                        return result;
                    }

                    string query = @"
                UPDATE Projects
                SET
                    Name = @Name,
                    Description = @Description,
                    ProjectManagerId = @ProjectManagerId,
                    StartDate = @StartDate,
                    TentativeClosingDate = @TentativeClosingDate,
                    AccountManagerId = @AccountManagerId
                WHERE ProjectId = @ProjectId";

                    DynamicParameters parameters = new DynamicParameters();

                    parameters.Add("ProjectId", Id);
                    parameters.Add("Name", project.Name);
                    parameters.Add("Description", project.Description);
                    parameters.Add("ProjectManagerId", project.ProjectManagerId);
                    parameters.Add("StartDate", project.StartDate);
                    parameters.Add("TentativeClosingDate", project.TentativeClosingDate);
                    parameters.Add("AccountManagerId", project.AccountManagerId);

                    int numRecordsAffected =
                        await dbConnection.ExecuteAsync(
                            query,
                            parameters,
                            transaction);

                    if (numRecordsAffected == 1)
                    {
                        transaction.Commit();

                        result.Status = OperationStatus.Success;
                        result.RecordsAffected = numRecordsAffected;
                        result.ResourceName = "Projects";
                        result.OperationPerformed = OperationPerformed.Update;

                        return result;
                    }
                    else
                    {
                        transaction.Rollback();

                        result.Status = OperationStatus.NotFound;
                        result.RecordsAffected = 0;
                        result.ResourceName = "Projects";
                        result.OperationPerformed = OperationPerformed.Update;

                        return result;
                    }
                }
                catch (Exception ex)
                {
                    transaction.Rollback();

                    result.Status = OperationStatus.UnknownException;
                    result.RecordsAffected = 0;
                    result.ResourceName = "Projects";
                    result.OperationPerformed = OperationPerformed.Update;
                    result.ExecptionMessage = ex.Message;

                    return result;
                }
                finally
                {
                    transaction.Dispose();
                }
            }
        }


        public async Task<ServiceResponse> Delete(int id)
        {
            ServiceResponse result = new ServiceResponse();

            string query = @"
                DELETE FROM Projects
                WHERE ProjectId = @Id";

            using (IDbConnection dbConnection =
                   _context.CreateConnection())
            {
                dbConnection.Open();

                try
                {
                    int numRecordsAffected =
                        await dbConnection.ExecuteAsync(
                            query,
                            new
                            {
                                Id = id
                            });

                    if (numRecordsAffected == 1)
                    {
                        result.Status = OperationStatus.Success;
                        result.RecordsAffected = numRecordsAffected;
                    }
                    else
                    {
                        result.Status = OperationStatus.NotFound;
                        result.RecordsAffected = 0;
                    }

                    result.ResourceName = "Projects";
                    result.OperationPerformed =
                        OperationPerformed.Delete;

                    return result;
                }
                catch (Exception ex)
                {
                    result.Status = OperationStatus.UnknownException;
                    result.RecordsAffected = 0;
                    result.ResourceName = "Projects";
                    result.OperationPerformed =
                        OperationPerformed.Delete;
                    result.ExecptionMessage = ex.Message;

                    return result;
                }
            }
        }


        public async Task<List<Project>> GetPagedList(
            int pageNumber,
            int pageSize)
        {
            int offset = (pageNumber - 1) * pageSize;

            string query = @"
                SELECT
                    ProjectId,
                    Name,
                    Description,
                    ProjectManagerId,
                    StartDate,
                    TentativeClosingDate,
                    AccountManagerId
                FROM Projects
                ORDER BY ProjectId
                OFFSET @Offset ROWS
                FETCH NEXT @PageSize ROWS ONLY";

            using (IDbConnection dbConnection =
                   _context.CreateConnection())
            {
                IEnumerable<Project> projects =
                    await dbConnection.QueryAsync<Project>(
                        query,
                        new
                        {
                            Offset = offset,
                            PageSize = pageSize
                        });

                return projects.ToList();
            }
        }


        public async Task<List<Project>> GetByProjectManager(
            int projectManagerId)
        {
            string query = @"
                SELECT
                    ProjectId,
                    Name,
                    Description,
                    ProjectManagerId,
                    StartDate,
                    TentativeClosingDate,
                    AccountManagerId
                FROM Projects
                WHERE ProjectManagerId = @ProjectManagerId";

            using (IDbConnection dbConnection =
                   _context.CreateConnection())
            {
                IEnumerable<Project> projects =
                    await dbConnection.QueryAsync<Project>(
                        query,
                        new
                        {
                            ProjectManagerId = projectManagerId
                        });

                return projects.ToList();
            }
        }
    }
}