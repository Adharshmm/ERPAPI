﻿using AutoMapper;
using Dapper;
using ERPAPI.Data.Dapper;
using ERPAPI.Data.EF;
using ERPAPI.Data.Entities;
using ERPAPI.Dtos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Net;
using System.Net.Http.Headers;
using System.Reflection.Metadata;
using ERPAPI.Services.DB.Interfaces;
using ERPAPI.Services.DB.Drapper;
namespace ERPAPI.Services.DB.Dapper
{
    public class EmployeeDA : DABase, IEmployeeLookupDA
    {
        private readonly EmployeeDapperContext _context;

        public EmployeeDA(EmployeeDapperContext context)
        {
            _context = context;
        }


        public async Task<int> Insert(Employee oEmployee)
        {


            string qryInsertEmployee = "INSERT INTO EmployeeDetails (firstName, lastName, dateofBirth, personalEmail, mobileNumber, postalAddress, gender, country, city, designation, basicPay, needTransportation, notes, username, password) VALUES (@firstName, @lastName, @dateofBirth, @personalEmail, @mobileNumber, @postalAddress, @gender, @country, @city, @designation, @basicPay, @needTransportation, @notes, @username, @password)";
            DynamicParameters parametrs = new DynamicParameters();
            parametrs.Add("firstName", oEmployee.FirstName);
            parametrs.Add("lastName", oEmployee.LastName);
            parametrs.Add("dateofBirth", oEmployee.DateofBirth);
            parametrs.Add("personalEmail", oEmployee.PersonalEmail);
            parametrs.Add("mobileNumber", oEmployee.MobileNumber);
            parametrs.Add("postalAddress", oEmployee.PostalAddress);
            parametrs.Add("gender", oEmployee.Gender);
            parametrs.Add("country", oEmployee.Country);
            parametrs.Add("city", oEmployee.City);
            parametrs.Add("designation", oEmployee.Designation);
            parametrs.Add("basicPay", oEmployee.BasicPay);
            parametrs.Add("needTransportation", oEmployee.NeedTransportation);
            parametrs.Add("notes", oEmployee.Notes ?? (object)DBNull.Value);
            parametrs.Add("username", oEmployee.Username);
            parametrs.Add("password", oEmployee.Password);

            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                dbConnection.Open();

                IDbTransaction transaction = dbConnection.BeginTransaction();

                try
                {
                    int numRecordsAffected = await dbConnection.ExecuteAsync(qryInsertEmployee, parametrs, transaction);
                    if (numRecordsAffected == 1)
                    {


                        int NewEmployeeId = dbConnection.ExecuteScalar<int>("SELECt @@IDENTITY", null, transaction);

                        foreach (WorkExperience workExperience in oEmployee.WorkExperiences)
                        {
                            workExperience.EmployeeId = NewEmployeeId;
                        }
                        string qryInsertWorkExperience = "INSERT INTO WorkExperiences (EmployeeId, Company, NumberOfMonths, LastDesignation, Remarks) VALUES (@EmployeeId, @Company, @NumberOfMonths, @LastDesignation, @Remarks);";
                        int numWorkExpAdded = await dbConnection.ExecuteAsync(qryInsertWorkExperience, oEmployee.WorkExperiences, transaction);
                        if (numWorkExpAdded == oEmployee.WorkExperiences.Count)
                        {
                            transaction.Commit();

                            return numRecordsAffected;
                        }
                        else
                        {
                            transaction.Rollback();
                            return numRecordsAffected;
                        }

                    }
                    else
                    {
                        transaction.Rollback();
                        return numRecordsAffected;
                    }

                }
                catch
                {
                    transaction.Rollback();
                    return -1;
                }
                finally
                {
                    transaction.Dispose();
                }

            }
        }

        public async Task<List<Employee>> GetList()
        {
            string qryGetEmployees = "SELECT * FROM EmployeeDetails";

            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                IEnumerable<Employee> employees = await dbConnection.QueryAsync<Employee>(qryGetEmployees);
                foreach (Employee employee in employees.ToList())
                {
                    string qryGetWorkExp = "select * from WorkExperiences where EmployeeId = @EmployeeId";
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("EmployeeId", employee.EmployeeId);

                    IEnumerable<WorkExperience> WorkExp = await dbConnection.QueryAsync<WorkExperience>(qryGetWorkExp, parameters);
                    employee.WorkExperiences = WorkExp.ToList();
                }


                return employees.ToList();
            }
        }



        public Boolean IsEmployeeListNull()
        {
            string qryGetEmployees = "SELECT CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END FROM EmployeeDetails";

            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                return dbConnection.ExecuteScalar<bool>(qryGetEmployees);
            }


        }

        public async Task<Employee> GetById(int Id)
        {
            string qryGetEmployees = "SELECT * FROM EmployeeDetails Where EmployeeId = @Id";

            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Id", Id);

            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                Employee objEmployee = await dbConnection.QuerySingleOrDefaultAsync<Employee>(qryGetEmployees, parameters);

                if (objEmployee != null)
                {
                    //get workexp
                    string qryGetWorkExp = "select * from WorkExperiences Where EmployeeId = @Id";

                    DynamicParameters WorkExParameter = new DynamicParameters();
                    WorkExParameter.Add("Id", objEmployee.EmployeeId);

                    IEnumerable<WorkExperience> WorkExp = await dbConnection.QueryAsync<WorkExperience>(qryGetWorkExp, WorkExParameter);
                    objEmployee.WorkExperiences = WorkExp.ToList();
                    return objEmployee;
                }
                else
                {
                    return objEmployee;
                }
            }

        }

        public async Task<int> EmpUpdate(Employee oemployee)
        {
            string qryUpdateEmployees = "UPDATE EmployeeDetails SET firstName=@firstName, lastName=@lastName, dateofBirth=@dateofBirth, personalEmail=@personalEmail, mobileNumber=@mobileNumber, postalAddress=@postalAddress, gender=@gender, country=@country, city=@city, designation=@designation, basicPay=@basicPay, needTransportation=@needTransportation, notes=@notes, username=@username, password=@password WHERE  EmployeeId = @Id";

            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Id", oemployee.EmployeeId);
            parameters.Add("firstName", oemployee.FirstName);
            parameters.Add("lastName", oemployee.LastName);
            parameters.Add("dateofBirth", oemployee.DateofBirth);
            parameters.Add("personalEmail", oemployee.PersonalEmail);
            parameters.Add("mobileNumber", oemployee.MobileNumber);
            parameters.Add("postalAddress", oemployee.PostalAddress);
            parameters.Add("gender", oemployee.Gender);
            parameters.Add("country", oemployee.Country);
            parameters.Add("city", oemployee.City);
            parameters.Add("designation", oemployee.Designation);
            parameters.Add("basicPay", oemployee.BasicPay);
            parameters.Add("needTransportation", oemployee.NeedTransportation);
            parameters.Add("notes", oemployee.Notes ?? (object)DBNull.Value);
            parameters.Add("username", oemployee.Username);
            parameters.Add("password", oemployee.Password);

            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                dbConnection.Open();
                IDbTransaction transaction = dbConnection.BeginTransaction();

                try
                {
                    int numRecordsAffected = await dbConnection.ExecuteAsync(qryUpdateEmployees, parameters, transaction);
                    if (numRecordsAffected == 1)
                    {
                        //delete exsisting workexp
                        string qryDeleteWorkExp = "Delete from WorkExperiences where EmployeeId = @Id ";
                        DynamicParameters deleteWrkExParameter = new DynamicParameters();
                        deleteWrkExParameter.Add("Id", oemployee.EmployeeId);

                        await dbConnection.ExecuteAsync(qryDeleteWorkExp, deleteWrkExParameter, transaction);
                        foreach (WorkExperience workExperience in oemployee.WorkExperiences)
                        {
                            workExperience.EmployeeId = oemployee.EmployeeId;
                        }
                        string qryInsertWorkExperience = "INSERT INTO WorkExperiences (EmployeeId, Company, NumberOfMonths, LastDesignation, Remarks) VALUES (@EmployeeId, @Company, @NumberOfMonths, @LastDesignation, @Remarks);";
                        int numWorkExpAdded = await dbConnection.ExecuteAsync(qryInsertWorkExperience, oemployee.WorkExperiences, transaction);
                        if (numWorkExpAdded == oemployee.WorkExperiences.Count)
                        {
                            transaction.Commit();

                            return numRecordsAffected;
                        }
                        else
                        {
                            transaction.Rollback();
                            return -1;
                        }

                    }
                    else
                    {
                        transaction.Rollback();
                        return -1;
                    }

                }
                catch (Exception)
                {
                    transaction.Rollback();
                    return 0;
                }
                finally
                {
                    transaction.Dispose();
                }

            }

        }

        public async Task<int> DeleteEmp(Employee oEmployee)
        {
            string qryDeleteWorkExp = "DELETE FROM WorkExperiences WHERE employeeId = @Id ";
            string qryDeleteEmployees = "DELETE FROM EmployeeDetails WHERE employeeId = @Id ";
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("Id", oEmployee.EmployeeId);
            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                dbConnection.Open();
                IDbTransaction transaction = dbConnection.BeginTransaction();
                try
                {
                    await dbConnection.ExecuteAsync(qryDeleteWorkExp, parameters, transaction);

                    int numRecordsAffected = await dbConnection.ExecuteAsync(qryDeleteEmployees, parameters, transaction);
                    if (numRecordsAffected == 1)
                    {
                        transaction.Commit();
                        return numRecordsAffected;
                    }
                    else
                    {
                        transaction.Rollback();
                        return numRecordsAffected;
                    }

                }
                catch
                {
                    transaction.Rollback();
                    return 0;
                }
                finally
                {
                    transaction.Dispose();
                }
            }
        }

        public async Task<List<Employee>> GetProjectManagers()
        {
            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                string query = @"
            SELECT *
            FROM EmployeeDetails
            WHERE Designation IN
            (
                'Team Leader',
                'Project Leader',
                'Project Manager',
                'Vice President'
            )";

                var result = await dbConnection.QueryAsync<Employee>(query);

                return result.ToList();
            }
        }
        public async Task<List<Employee>> GetVicePresidents()
        {
            using (IDbConnection dbConnection = _context.CreateConnection())
            {
                string query = @"
            SELECT *
            FROM EmployeeDetails
            WHERE Designation = 'Vice President'";

                var result = await dbConnection.QueryAsync<Employee>(query);

                return result.ToList();
            }
        }


    }

}