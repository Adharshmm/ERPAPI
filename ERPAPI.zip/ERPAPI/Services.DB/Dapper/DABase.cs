﻿namespace ERPAPI.Services.DB.Drapper
{
    public class DABase
    {
    }
}
