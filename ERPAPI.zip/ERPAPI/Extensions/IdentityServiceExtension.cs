﻿using Microsoft.AspNetCore.Identity;
using ERPAPI.Data.EF;
using Microsoft.EntityFrameworkCore;
using ERPAPI.Data.Entities;

namespace ERPAPI.Extensions
{
    public static class IdentityServiceExtension
    {

        public static IServiceCollection AddIdentityServices(this IServiceCollection services,IConfiguration configuration) {
            services.AddDbContext<EmployeeDetailsDBContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("EmployeeDetailsDB")));
            services.AddIdentity<ApplicationUser, IdentityRole>()
                .AddDefaultTokenProviders()
                .AddEntityFrameworkStores<EmployeeDetailsDBContext>();
            return services;
        }
    }
}
